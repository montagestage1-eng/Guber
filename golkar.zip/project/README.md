# Jadi Cowok Satu-satunya di Dunia atau Bos Kelapa Sawit?

Video animasi komedi vertikal 9:16 (1080 x 1920, 30 fps, 35 detik / 1050 frame) dengan Remotion 4 (React + TypeScript).
Tidak ada header, judul, nomor adegan, atau logo di dalam video.

## STATUS JUJUR (baca dulu)

- Kode sudah lolos pemeriksaan tipe TypeScript dan frame-frame kuncinya sudah dirender untuk dicek (`docs/preview-frames.png`),
  **tetapi memakai modul `remotion` tiruan** karena lingkungan pembuatan tidak punya akses internet.
  **Render MP4 asli dengan Remotion belum pernah dijalankan.** Jalankan `npm run dev` lalu `npm run render` di komputer Anda;
  bila ada galat, kirimkan pesan galatnya.
- `public/narasi.mp3` adalah **placeholder hening 35 detik**. Ganti dengan narasi asli (nama file sama).
- `public/sounds/*.mp3` adalah **placeholder sintetis** buatan ffmpeg (bunyi bip sederhana), bukan efek suara asli. Ganti dengan SFX berlisensi bebas
  bernama sama; daftar cue ada di `src/components/SoundEffects.tsx`. Skrip pembuatnya: `tools/gen-placeholder-sounds.sh`.
- **Semua timing subtitle dan efek adalah PERKIRAAN** dari SRT dan belum disinkronkan dengan audio asli.
  Setelah `narasi.mp3` asli dipasang: sesuaikan `AUDIO_OFFSET` dan nilai di `src/data/captions.ts`, `src/data/beats.ts`, `src/components/SoundEffects.tsx`.
- Durasi 35 detik (bukan 30) karena SRT berakhir di 33,8 detik. Suara tidak dipercepat.

## Instalasi (Windows)

1. Pasang **Node.js LTS** dari https://nodejs.org (centang opsi default).
2. Ekstrak ZIP, buka foldernya.
3. Klik kolom alamat folder, ketik `cmd`, tekan Enter (terminal terbuka di folder proyek).
4. Jalankan `npm install` (lama pada pertama kali; Remotion mengunduh Chromium).
5. Jalankan `npm run dev` lalu buka alamat yang tampil (biasanya http://localhost:3000) untuk pratinjau.
6. Jalankan `npm run render` untuk membuat video.
7. Hasil: `out/cowok-sawit.mp4`.

Frame tunggal untuk dicek: `npm run still` (hasil `out/frame.png`).

Jika hanya punya Android: Remotion butuh Node.js dan Chromium sehingga tidak berjalan native di Android. Gunakan komputer,
atau lingkungan cloud (misalnya GitHub Codespaces, Gitpod, atau StackBlitz) lalu unggah folder proyek dan jalankan perintah yang sama.

## Struktur

```
public/narasi.mp3 narasi.srt sounds/      aset audio dan SRT
src/index.ts Root.tsx Video.tsx           registrasi, Composition tunggal, urutan beat
src/beats/Beat01..06.tsx                  enam beat sesuai storyboard
src/components/                           karakter, latar, efek, kamera, split screen, subtitle, SFX
src/data/layout.ts beats.ts captions.ts   koordinat 1080x1920, timing beat, caption
tools/gen-placeholder-sounds.sh           pembuat placeholder suara (butuh ffmpeg)
docs/preview-frames.png                   pratinjau frame kunci (dari harness tiruan)
```

## Catatan teknis

- Semua animasi memakai `useCurrentFrame`, `interpolate`, `spring`, dan `Sequence`; tanpa CSS animation, `setTimeout`, atau `Math.random` (acak ber-seed lewat `random()`).
- Karakter digambar sebagai SVG berlapis di kode (bukan gambar statis), mengikuti character sheet.
- Split screen beat 04 dibuat **diagonal atas-bawah** (bukan kiri-kanan) agar karakter tetap besar di layar 9:16.
- Whip pan beat 01 ke 02 memakai tumpang tindih 10 frame (`WHIP_OVERLAP`), jadi Beat 01 berjalan 157 frame.
- Versi Remotion dikunci `4.0.418`. Remotion 5 belum dirilis saat proyek dibuat dan punya perubahan (mis. kunci lisensi); jangan naik versi tanpa membaca panduan migrasi.
- Remotion gratis untuk individu dan tim kecil; cek ketentuan lisensi di https://www.remotion.dev/license untuk penggunaan komersial.
