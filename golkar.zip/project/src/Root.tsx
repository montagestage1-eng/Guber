import type {FC} from 'react';
import {Composition} from 'remotion';
import {Video} from './Video';
import {FPS, H, TOTAL_FRAMES, W} from './data/layout';

export const RemotionRoot: FC = () => {
  return (
    <Composition
      id="CowokSawit"
      component={Video}
      durationInFrames={TOTAL_FRAMES}
      fps={FPS}
      width={W}
      height={H}
    />
  );
};
