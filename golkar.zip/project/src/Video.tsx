import type {FC} from 'react';
import {AbsoluteFill, Html5Audio, Sequence, staticFile} from 'remotion';
import {Beat01} from './beats/Beat01';
import {Beat02} from './beats/Beat02';
import {Beat03} from './beats/Beat03';
import {Beat04} from './beats/Beat04';
import {Beat05} from './beats/Beat05';
import {Beat06} from './beats/Beat06';
import {SoundEffects} from './components/SoundEffects';
import {Subtitle} from './components/Subtitle';
import {BEATS, WHIP_OVERLAP} from './data/beats';

const BEAT_COMPONENTS: FC[] = [Beat01, Beat02, Beat03, Beat04, Beat05, Beat06];

// Tidak ada header, judul, nomor adegan, atau logo permanen di video ini.
export const Video: FC = () => (
  <AbsoluteFill style={{backgroundColor: '#000'}}>
    {BEATS.map((b, i) => {
      const C = BEAT_COMPONENTS[i];
      return (
        <Sequence key={b.id} from={b.start} durationInFrames={b.dur + (i === 0 ? WHIP_OVERLAP : 0)} name={`Beat ${String(b.id).padStart(2, '0')}`}>
          <C />
        </Sequence>
      );
    })}
    <Subtitle />
    {/* Narasi = acuan utama timing. public/narasi.mp3 saat ini PLACEHOLDER hening: ganti dengan audio asli. */}
    <Html5Audio src={staticFile('narasi.mp3')} />
    <SoundEffects />
  </AbsoluteFill>
);
