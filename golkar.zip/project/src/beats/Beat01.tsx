import type {FC} from 'react';
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {Camera} from '../components/Camera';
import {ChoiceSymbols} from './parts';
import {HomeBackground} from '../components/HomeBackground';
import {ComicMark} from '../components/Overlays';
import {MainCharacter} from '../components/MainCharacter';
import type {Expr} from '../components/CharacterExpressions';
import {LAYOUT} from '../data/layout';
import {kf} from '../utils';

// BEAT 01 - Hook: dua pilihan hidup (frame 0-147)
export const Beat01: FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const L = LAYOUT.b1;

  const enter = spring({frame: f, fps, config: {damping: 11, stiffness: 150, mass: 0.7}});
  const stretch = 1 + (1 - Math.min(1, enter)) * 0.2;
  const expr: Expr = f < 62 ? 'thinking' : 'smug';
  const point = kf(f, [88, 100], [0, 1]);
  const chin = [172, 244] as const;
  const aim = [238, 300] as const;
  const armR = {
    t: [chin[0] + (aim[0] - chin[0]) * point, chin[1] + (aim[1] - chin[1]) * point] as [number, number],
    bend: -1 as const,
    hs: 1 + point * 0.8,
  };
  const tilt = kf(f, [26, 42, 100, 114], [0, -8, -8, 0]);
  const qPop = spring({frame: f - 14, fps, config: {damping: 9, stiffness: 200}});

  // whip pan keluar: 10 frame tumpang tindih dengan awal Beat 02 (lihat Video.tsx)
  const out = kf(f, [147, 157], [0, 1]);

  return (
    <AbsoluteFill style={{transform: `translateX(${-out * 1080}px)`, filter: `blur(${out * 14}px)`}}>
      <Camera f={f} zoom={[[0, 1], [10, 1], [40, 1.16], [146, 1.18]]} origin={[540, 950]} shake={{from: 87, to: 104, amp: 9}}>
        <HomeBackground palette="blue" seed={1} />
        <MainCharacter
          box={L.character}
          expr={expr}
          crop="upper"
          dx={(1 - enter) * -1000}
          sx={stretch}
          sy={1 / stretch}
          armR={armR}
          armL={{t: [112, 338], bend: 1}}
          headTilt={tilt}
          look={[expr === 'thinking' ? 5 : 0, expr === 'thinking' ? -5 : 0]}
          blink={f % 100 < 3}
          hairSway={Math.sin(f * 0.2) * 2}
        />
        <ComicMark x={L.questionMark.x} y={L.questionMark.y} w={L.questionMark.w} h={L.questionMark.h} char="?" color="#ffd800" scale={qPop} rot={Math.sin(f * 0.15) * 6} />
        <ChoiceSymbols f={f} />
      </Camera>
    </AbsoluteFill>
  );
};
