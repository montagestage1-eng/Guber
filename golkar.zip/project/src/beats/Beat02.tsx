import type {FC} from 'react';
import {AbsoluteFill, Easing, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {Camera} from '../components/Camera';
import {FantasyWorldBackground} from '../components/FantasyWorldBackground';
import {GirlCharacter} from '../components/GirlCharacter';
import {HeartEffects} from '../components/HeartEffects';
import {MainCharacter} from '../components/MainCharacter';
import {BurstOverlay, Sparkle} from '../components/Overlays';
import {H, LAYOUT, W, type Box} from '../data/layout';
import {clamp, kf} from '../utils';

type GirlDef = {box: Box; delay: number; from: number; flip: boolean; love: boolean; opacity: number};

// BEAT 02 - Pilihan 1: cowok satu-satunya di dunia (frame 0-243)
export const Beat02: FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const L = LAYOUT.b2;

  const girls: GirlDef[] = [
    {box: L.girlFarL, delay: 14, from: -200, flip: false, love: true, opacity: 0.85},
    {box: L.girlFarR, delay: 18, from: 200, flip: true, love: false, opacity: 0.85},
    {box: L.girlBackL, delay: 10, from: -240, flip: false, love: false, opacity: 0.92},
    {box: L.girlBackR, delay: 12, from: 240, flip: true, love: true, opacity: 0.92},
    {box: L.girlFrontL, delay: 20, from: -320, flip: false, love: true, opacity: 1},
    {box: L.girlFrontR, delay: 24, from: 320, flip: true, love: false, opacity: 1},
  ];

  // whip pan masuk dari kanan (10 frame pertama)
  const inP = kf(f, [0, 10], [1, 0]);

  // mahkota jatuh dan memantul tepat di "satu-satunya" (frame 48 ~ detik 6,5)
  const drop = clamp((f - 44) / 18, 0, 1);
  const crown = f < 44 ? -700 : -700 * (1 - Easing.bounce(drop));
  const pulse = kf(f, [44, 52, 72], [0, 1, 0]);

  const wave = f > 110 && f < 196 ? 1 : 0;
  const armR = {t: [262 + Math.sin(f * 0.3) * 18 * wave, 300 + Math.cos(f * 0.3) * 12 * wave] as [number, number], bend: -1 as const};
  const chinUp = kf(f, [50, 70], [0, -7]);
  const sc = spring({frame: f - 4, fps, config: {damping: 12, stiffness: 140}});

  return (
    <AbsoluteFill style={{transform: `translateX(${inP * 1080}px)`, filter: `blur(${inP * 14}px)`}}>
      <Camera
        f={f}
        zoom={[[0, 1], [150, 1.1], [192, 1.2], [214, 2.25], [243, 2.3]]}
        origin={[540, 758]}
      >
        <FantasyWorldBackground pulse={pulse} />
        <HeartEffects seed={3} count={16} start={20} />
        {girls.map((g, i) => {
          const s = spring({frame: f - g.delay, fps, config: {damping: 13, stiffness: 110}});
          return (
            <GirlCharacter
              key={i}
              box={g.box}
              flip={g.flip}
              expr={g.love ? 'love' : 'cheer'}
              dx={(1 - s) * g.from}
              dy={Math.sin(f * 0.2 + i * 1.3) * 9}
              rot={Math.sin(f * 0.15 + i) * 3}
              opacity={g.opacity * Math.min(1, s * 2)}
            />
          );
        })}
        <MainCharacter
          box={L.character}
          expr="smug"
          crop="full"
          crown={crown}
          sx={0.9 + sc * 0.1}
          sy={0.9 + sc * 0.1}
          armR={armR}
          armL={{t: [112, 338], bend: 1}}
          headTilt={chinUp}
          blink={f % 110 < 3}
          hairSway={Math.sin(f * 0.18) * 2}
        />
        <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0, pointerEvents: 'none'}}>
          {f >= 44 &&
            [[360, 620], [720, 600], [300, 900], [790, 880], [540, 540]].map((p, i) => (
              <Sparkle key={i} f={f} x={p[0]} y={p[1]} size={34} phase={i * 1.4} color={i % 2 ? '#ffffff' : '#ffe08a'} />
            ))}
          {f >= 44 && f < 62 && (
            <circle cx={540} cy={640} r={(f - 44) * 38} fill="none" stroke="#fff6c8" strokeWidth={14} opacity={1 - (f - 44) / 18} />
          )}
        </svg>
      </Camera>
      <BurstOverlay f={f} from={231} dur={12} mode="out" color="#ff9ac2" icon="heart" />
    </AbsoluteFill>
  );
};
