import type {FC} from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {BossCharacter} from '../components/BossCharacter';
import {Camera} from '../components/Camera';
import {MoneyEffects} from '../components/MoneyEffects';
import {BurstOverlay, DiagWipe, Sparkle} from '../components/Overlays';
import {PalmOilBossScene} from '../components/PalmOilBossScene';
import type {Expr} from '../components/CharacterExpressions';
import {H, W} from '../data/layout';
import {kf} from '../utils';

// BEAT 03 - Pilihan 2: bos kelapa sawit (frame 0-255)
export const Beat03: FC = () => {
  const f = useCurrentFrame();

  const dx = kf(f, [24, 46], [900, 0]);
  // berbalik menghadap kamera (scaleX -1 -> 1) setelah masuk
  const sx = f < 38 ? -1 : f < 46 ? kf(f, [38, 46], [-1, 1]) : 1;
  const glasses = kf(f, [39, 47], [0, 1]);
  const lean = kf(f, [158, 172], [0, 1]);
  const expr: Expr = f < 70 ? 'smug' : f < 160 ? 'happy' : 'laughing';

  return (
    <AbsoluteFill>
      <Camera f={f} zoom={[[0, 1], [60, 1], [200, 1.22], [254, 1.3]]} origin={[540, 1050]}>
        <PalmOilBossScene scroll={f * 0.2} truckDx={Math.sin(f * 0.03) * 24}>
          <BossCharacter f={f} expr={expr} lean={lean} glasses={glasses} sx={sx} dx={dx} blink={f % 95 < 3} />
        </PalmOilBossScene>
        <MoneyEffects start={78} count={18} origin={[540, 1050]} seed={5} gravity={520} />
        <MoneyEffects start={132} count={10} origin={[560, 1100]} seed={9} gravity={450} />
        <MoneyEffects start={210} count={12} origin={[620, 1000]} seed={13} gravity={500} coins />
        <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0, pointerEvents: 'none'}}>
          {f >= 47 && f < 80 && (
            <>
              <Sparkle f={f} x={452} y={930} size={34} />
              <Sparkle f={f} x={640} y={925} size={26} phase={2} />
            </>
          )}
        </svg>
      </Camera>
      <BurstOverlay f={f} from={0} dur={12} mode="in" color="#ffd75a" icon="coin" />
      <DiagWipe f={f} from={250} dur={5} mode="in" />
    </AbsoluteFill>
  );
};
