import type {FC} from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {BossCharacter} from '../components/BossCharacter';
import {Camera} from '../components/Camera';
import {FantasyWorldBackground} from '../components/FantasyWorldBackground';
import {GirlCharacter} from '../components/GirlCharacter';
import {HeartEffects} from '../components/HeartEffects';
import {MainCharacter} from '../components/MainCharacter';
import {DiagWipe, Flash, SpeedLines} from '../components/Overlays';
import {PalmOilBossScene} from '../components/PalmOilBossScene';
import {SplitScreen} from '../components/SplitScreen';
import {TaxBillEffects} from '../components/TaxBillEffects';
import type {Expr} from '../components/CharacterExpressions';
import {H, LAYOUT, W} from '../data/layout';
import {kf, type Vec} from '../utils';

const PANIC_AT = 114; // "tagihan pajak" ~ detik 25,3 (frame lokal 114)
const RUN_AT = 124;

// BEAT 04 - Perbandingan dan punchline (frame 0-162)
export const Beat04: FC = () => {
  const f = useCurrentFrame();
  const L = LAYOUT.b4;

  const runDx = f < RUN_AT ? 0 : kf(f, [RUN_AT, 162], [0, 700], (n) => n);
  const jump = kf(f, [PANIC_AT, PANIC_AT + 5, RUN_AT], [0, -110, 0]);
  const bossExpr: Expr = f < 70 ? 'smug' : f < PANIC_AT ? 'happy' : 'panic';
  const running = f >= RUN_AT;
  const phase = (f - RUN_AT) * 0.9;

  const target = (frame: number): Vec => [560 + (frame < RUN_AT ? 0 : kf(frame, [RUN_AT, 162], [0, 700], (n) => n)), 1250];

  const wave = Math.sin(f * 0.3);
  const top = (
    <>
      <FantasyWorldBackground seed={7} />
      <HeartEffects seed={4} count={14} area={{x: 0, y: 0, w: W, h: L.topPanelHeight}} />
      <GirlCharacter box={L.girlL} expr="love" dy={Math.sin(f * 0.2) * 8} />
      <GirlCharacter box={L.girlR} expr="cheer" flip dy={Math.cos(f * 0.2) * 8} />
      <MainCharacter
        box={L.topCharacter}
        expr="smug"
        crown={0}
        crop="full"
        armR={{t: [262 + wave * 14, 304], bend: -1}}
        armL={{t: [112, 338], bend: 1}}
        headTilt={-5}
        blink={f % 100 < 3}
      />
    </>
  );

  const bottom = (
    <>
      <PalmOilBossScene ty={L.bottomSceneOffsetY} scroll={f * 0.2}>
        <BossCharacter
          f={f}
          expr={bossExpr}
          lean={running ? 0 : 1}
          running={running}
          runPhase={phase}
          dx={runDx}
          dy={jump}
          sx={running ? 1 : 1}
        />
      </PalmOilBossScene>
      <TaxBillEffects start={PANIC_AT} origin={[500, 1240]} target={target} />
      <SpeedLines f={f} from={RUN_AT} dur={36} region={[900, 1500]} />
    </>
  );

  return (
    <AbsoluteFill>
      <Camera f={f} shake={{from: PANIC_AT, to: PANIC_AT + 26, amp: 14}}>
        <SplitScreen
          top={top}
          bottom={bottom}
          topX={kf(f, [0, 8], [-W, 0])}
          bottomX={kf(f, [0, 8], [W, 0])}
          topDim={kf(f, [PANIC_AT - 2, PANIC_AT + 8], [0, 0.55])}
          bottomZoom={kf(f, [PANIC_AT, PANIC_AT + 15], [1, 1.3])}
          bottomOrigin={[540, 1250]}
        />
      </Camera>
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0, pointerEvents: 'none'}} />
      <Flash f={f} from={PANIC_AT} dur={5} color="#ff2a2a" />
      <DiagWipe f={f} from={0} dur={5} mode="out" />
      <DiagWipe f={f} from={157} dur={5} mode="in" color="#d62828" flip />
    </AbsoluteFill>
  );
};
