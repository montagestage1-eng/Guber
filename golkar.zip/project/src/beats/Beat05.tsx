import type {FC} from 'react';
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {Camera} from '../components/Camera';
import {SymbolGirl, SymbolPalm} from '../components/ChoiceSymbols';
import {HomeBackground} from '../components/HomeBackground';
import {MainCharacter} from '../components/MainCharacter';
import {ComicMark, DiagWipe, Flash} from '../components/Overlays';
import {LAYOUT} from '../data/layout';
import {kf} from '../utils';

// BEAT 05 - Pertanyaan ke penonton (frame 0-75). Frame 46-75 = jeda komedi.
export const Beat05: FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const L = LAYOUT.b5;

  const step = spring({frame: f, fps, config: {damping: 13, stiffness: 130}});
  const scale = 0.9 + step * 0.1;
  const tilt = kf(f, [20, 34, 48], [0, -8, -8]);
  const qPop = spring({frame: f - 8, fps, config: {damping: 9, stiffness: 200}});
  const bob = Math.sin(f * 0.18);

  return (
    <AbsoluteFill>
      <Camera f={f} zoom={[[0, 1], [74, 1.14]]} origin={[540, 950]}>
        <HomeBackground palette="red" seed={4} />
        <SymbolGirl box={L.iconLeft} scale={0.9} dy={bob * 8} rot={-8} />
        <SymbolPalm box={L.iconRight} scale={0.9} dy={-bob * 8} rot={8} />
        <MainCharacter
          box={L.character}
          expr="challenge"
          crop="upper"
          sx={scale}
          sy={scale}
          headTilt={tilt}
          armR={{t: [236, 300], bend: -1, hs: 1.9}}
          armL={{t: [112, 338], bend: 1}}
          blink={false}
          hairSway={Math.sin(f * 0.2) * 2}
        />
        <ComicMark x={L.questionMark.x} y={L.questionMark.y} w={L.questionMark.w} h={L.questionMark.h} char="?" color="#ffd800" scale={qPop} rot={Math.sin(f * 0.2) * 7} />
      </Camera>
      <DiagWipe f={f} from={0} dur={4} mode="out" color="#d62828" flip />
      <Flash f={f} from={72} dur={3} />
    </AbsoluteFill>
  );
};
