import type {FC} from 'react';
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {BedroomEnvironment} from '../components/BedroomEnvironment';
import {Camera} from '../components/Camera';
import {MainCharacter} from '../components/MainCharacter';
import {ComicMark, Flash} from '../components/Overlays';
import type {Expr} from '../components/CharacterExpressions';
import {H, LAYOUT, W} from '../data/layout';
import {kf} from '../utils';

const FREEZE_AT = 138; // 30 frame terakhir = freeze frame wajah pasrah

// BEAT 06 - Ending: yaelah, cuma mimpi (frame 0-168)
export const Beat06: FC = () => {
  const raw = useCurrentFrame();
  const {fps} = useVideoConfig();
  const f = Math.min(raw, FREEZE_AT);
  const L = LAYOUT.b6;

  const jolt = spring({frame: f - 6, fps, config: {damping: 8, stiffness: 180, mass: 0.7}});
  const fall = spring({frame: f - 108, fps, config: {damping: 10, stiffness: 160}});
  // rebah di bantal (55) -> tersentak duduk (0) -> jatuh kembali setengah rebah (28)
  const bodyTilt = f < 6 ? 55 : f < 108 ? 55 * (1 - jolt) : 28 * fall;
  const expr: Expr = f < 44 ? 'panic' : f < 60 ? 'shocked' : f < 100 ? 'flat' : 'sleepy';
  const look: [number, number] =
    f < 24
      ? [0, 0]
      : f < 44
        ? [kf(f, [24, 30, 36, 42], [-9, 9, -9, 9]), 0]
        : f < 60
          ? [-10, 10]
          : f < 100
            ? [kf(f, [60, 76, 90], [8, -8, 0]), -4]
            : [0, -8];
  const thud = kf(f, [108, 112, 120], [0, 1, 0]);
  const exclaim = f >= 6 && f < 44;
  const ringing = f >= 6 && f < 84;

  return (
    <AbsoluteFill>
      <Camera
        f={f}
        zoom={[[0, 2.3], [28, 2.3], [52, 1.12], [112, 1.12], [150, 1.7]]}
        rotate={[[0, -5], [FREEZE_AT, -5]]}
        origin={[560, 1000]}
      >
        <BedroomEnvironment light={kf(f, [6, 80], [0, 1])} ringing={ringing} frame={f} blanketLift={f >= 6 && f < 30 ? kf(f, [6, 14, 30], [0, 50, 0]) : thud * 20}>
          <MainCharacter
            box={L.character}
            expr={expr}
            crop="upper"
            shadow={false}
            bodyTilt={bodyTilt}
            pivot={[150, 330]}
            headTilt={f >= 108 ? 14 * fall : 0}
            look={look}
            sy={1 - thud * 0.04}
            sx={1 + thud * 0.04}
          />
        </BedroomEnvironment>
        {exclaim && (
          <ComicMark
            x={L.exclaim.x}
            y={L.exclaim.y}
            w={L.exclaim.w}
            h={L.exclaim.h}
            char="!!"
            color="#e01e2d"
            scale={0.9 + Math.sin(f * 0.9) * 0.08}
            rot={Math.sin(f * 0.7) * 8}
          />
        )}
        {exclaim && (
          <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0, pointerEvents: 'none'}}>
            <g transform={`translate(330 800) rotate(${f * 14})`}>
              <path d="M0,0 C30,-30 70,0 40,34 C14,56 -30,34 -18,0 C-10,-26 24,-30 30,-8" stroke="#111" strokeWidth={9} fill="none" strokeLinecap="round" />
            </g>
          </svg>
        )}
        {f >= 100 && f < 124 && (
          <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0, pointerEvents: 'none'}}>
            {[0, 1, 2].map((i) => (
              <circle key={i} cx={480 - (f - 100) * 3 - i * 26} cy={1060 - (f - 100) * 1.5 + i * 10} r={14 + (f - 100) * 0.9 + i * 6} fill="#fff" opacity={Math.max(0, 0.7 - (f - 100) / 34)} />
            ))}
          </svg>
        )}
      </Camera>
      <Flash f={raw} from={0} dur={4} />
    </AbsoluteFill>
  );
};
