import type {FC} from 'react';
import {spring, useVideoConfig} from 'remotion';
import {SymbolGirl, SymbolPalm} from '../components/ChoiceSymbols';
import {LAYOUT} from '../data/layout';
import {kf} from '../utils';

// Dua simbol pilihan yang muncul singkat di beat 01 (frame lokal 87-130).
export const ChoiceSymbols: FC<{f: number}> = ({f}) => {
  const {fps} = useVideoConfig();
  const L = LAYOUT.b1;
  const popL = spring({frame: f - 87, fps, config: {damping: 9, stiffness: 220}});
  const popR = spring({frame: f - 93, fps, config: {damping: 9, stiffness: 220}});
  const gone = kf(f, [124, 132], [1, 0]);
  if (f < 87) return null;
  return (
    <>
      <SymbolGirl box={L.symbolLeft} scale={popL * gone} dy={Math.sin(f * 0.2) * 6} rot={-6} />
      <SymbolPalm box={L.symbolRight} scale={popR * gone} dy={Math.cos(f * 0.2) * 6} rot={6} />
    </>
  );
};
