import type {FC, ReactNode} from 'react';
import {AbsoluteFill} from 'remotion';
import {H, LAYOUT, W} from '../data/layout';

const INK = '#0b1230';

type Props = {
  children?: ReactNode; // karakter, disisipkan di antara kasur dan selimut
  light?: number; // 0..1 cahaya pagi
  ringing?: boolean;
  frame?: number;
  blanketLift?: number;
};

const Clock: FC<{ringing: boolean; frame: number}> = ({ringing, frame}) => {
  const c = LAYOUT.b6.clock;
  const jit = ringing ? Math.sin(frame * 2.6) * 3 : 0;
  const colon = Math.floor(frame / 15) % 2 === 0 || ringing;
  return (
    <svg
      style={{position: 'absolute', left: c.x, top: c.y, width: c.w, height: c.h, overflow: 'visible', transform: `translate(${jit}px, 0) rotate(${jit}deg)`, transformOrigin: '50% 100%'}}
      viewBox="0 0 240 190"
    >
      <ellipse cx={120} cy={180} rx={110} ry={8} fill="rgba(0,0,0,0.3)" />
      <path d="M50,38 Q70,6 98,36 Z" fill="#9aa0b4" stroke="#000" strokeWidth={4} />
      <path d="M142,36 Q170,6 190,38 Z" fill="#9aa0b4" stroke="#000" strokeWidth={4} />
      <rect x={8} y={36} width={224} height={136} rx={22} fill="#1b1b21" stroke="#000" strokeWidth={6} />
      <rect x={24} y={54} width={192} height={98} rx={10} fill="#070709" />
      <text x={98} y={128} textAnchor="end" fontFamily="'Courier New', monospace" fontWeight={900} fontSize={66} fill="#ff2a2a">
        07
      </text>
      <text x={117} y={124} textAnchor="middle" fontFamily="'Courier New', monospace" fontWeight={900} fontSize={62} fill="#ff2a2a" opacity={colon ? 1 : 0.15}>
        :
      </text>
      <text x={136} y={128} textAnchor="start" fontFamily="'Courier New', monospace" fontWeight={900} fontSize={66} fill="#ff2a2a">
        00
      </text>
      {ringing && (
        <g stroke="#ffd800" strokeWidth={6} strokeLinecap="round">
          <path d="M20,22 L6,8 M60,10 L56,-8 M180,10 L184,-8 M220,22 L234,8" />
        </g>
      )}
    </svg>
  );
};

// Kamar sederhana: kasur, bantal, selimut, meja kecil, jam digital 07:00.
export const BedroomEnvironment: FC<Props> = ({children, light = 0, ringing = false, frame = 0, blanketLift = 0}) => (
  <AbsoluteFill>
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
      <defs>
        <linearGradient id="bd-wall" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#27386e" />
          <stop offset="100%" stopColor="#141c40" />
        </linearGradient>
        <linearGradient id="bd-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#0b1330" />
          <stop offset="100%" stopColor="#35508f" />
        </linearGradient>
      </defs>
      <rect width={W} height={H} fill="url(#bd-wall)" />
      <rect y={1200} width={W} height={720} fill="#1a2146" />
      <rect y={1190} width={W} height={20} fill="#0e1433" />
      {/* jendela */}
      <rect x={90} y={300} width={360} height={440} rx={10} fill="url(#bd-sky)" stroke={INK} strokeWidth={14} />
      <path d="M270,300 L270,740 M90,520 L450,520" stroke={INK} strokeWidth={10} />
      <circle cx={360} cy={400} r={36} fill="#fff6c9" opacity={0.9 - light * 0.6} />
      {[[150, 360], [210, 450], [420, 600], [140, 640]].map((p, i) => (
        <circle key={i} cx={p[0]} cy={p[1]} r={4} fill="#fff" opacity={0.8 - light * 0.7} />
      ))}
      {/* poster miring */}
      <g transform="rotate(-6 740 480)">
        <rect x={640} y={340} width={200} height={270} fill="#3a4a86" stroke={INK} strokeWidth={8} />
        <circle cx={740} cy={440} r={44} fill="#5b6fb5" />
        <path d="M660,590 L720,500 L760,550 L800,490 L830,590 Z" fill="#26346a" />
      </g>
      {/* meja kecil */}
      <rect x={30} y={1230} width={320} height={26} rx={6} fill="#7a5230" stroke="#000" strokeWidth={5} />
      <rect x={60} y={1256} width={24} height={250} fill="#5e3e22" stroke="#000" strokeWidth={4} />
      <rect x={296} y={1256} width={24} height={250} fill="#5e3e22" stroke="#000" strokeWidth={4} />
      {/* kasur */}
      <rect x={790} y={880} width={310} height={900} rx={24} fill="#6b4a2f" stroke="#000" strokeWidth={7} />
      <rect x={-40} y={1250} width={1160} height={540} rx={36} fill="#cfd8ee" stroke="#000" strokeWidth={7} />
      <rect x={-40} y={1740} width={1160} height={120} fill="#5e3e22" stroke="#000" strokeWidth={6} />
      <rect x={700} y={1110} width={340} height={170} rx={64} fill="#f4f6fc" stroke="#000" strokeWidth={6} />
      {light > 0 && <rect width={W} height={H} fill="#ffd89a" opacity={light * 0.18} />}
    </svg>
    <Clock ringing={ringing} frame={frame} />
    {children}
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
      <g transform={`translate(0 ${-blanketLift})`}>
        <path
          d="M-40,1330 Q200,1250 520,1290 Q760,1300 900,1360 L920,1780 L-40,1780 Z"
          fill="#4f78d1"
          stroke="#223a7a"
          strokeWidth={7}
          strokeLinejoin="round"
        />
        <path d="M60,1420 Q300,1380 560,1430 M40,1540 Q320,1500 640,1550 M20,1660 Q300,1630 700,1670" stroke="#35539c" strokeWidth={6} fill="none" strokeLinecap="round" />
      </g>
    </svg>
  </AbsoluteFill>
);
