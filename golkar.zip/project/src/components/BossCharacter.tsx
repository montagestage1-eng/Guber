import type {FC} from 'react';
import {LAYOUT} from '../data/layout';
import {lerpV, type Vec} from '../utils';
import type {Expr} from './CharacterExpressions';
import {LEGS, MainCharacter} from './MainCharacter';

type Props = {
  f: number;
  expr: Expr;
  lean?: number; // 0 duduk tegak, 1 bersandar dengan kaki terangkat
  glasses?: number;
  sx?: number;
  dx?: number;
  dy?: number;
  running?: boolean;
  runPhase?: number;
  blink?: boolean;
};

// Bos sawit: karakter sama + jas hitam + kacamata hitam + kipas uang. Dipakai beat 03 dan 04.
export const BossCharacter: FC<Props> = ({f, expr, lean = 0, glasses = 1, sx = 1, dx = 0, dy = 0, running = false, runPhase = 0, blink = false}) => {
  const legs = {l: lerpV(LEGS.sit.l, LEGS.lounge.l, lean) as Vec, r: lerpV(LEGS.sit.r, LEGS.lounge.r, lean) as Vec};
  if (running) {
    const s = Math.sin(runPhase);
    return (
      <MainCharacter
        box={LAYOUT.b3.character}
        expr={expr}
        crop="full"
        pose="run"
        runPhase={runPhase}
        suit
        glasses={glasses}
        sx={sx}
        dx={dx}
        dy={dy}
        bodyTilt={12}
        pivot={[150, 400]}
        armL={{t: [100 + 55 * s, 330], bend: 1}}
        armR={{t: [200 - 55 * s, 330], bend: -1}}
        hairSway={-8}
      />
    );
  }
  return (
    <MainCharacter
      box={LAYOUT.b3.character}
      expr={expr}
      crop="full"
      pose="sit"
      legs={legs}
      suit
      glasses={glasses}
      fan
      sx={sx}
      dx={dx}
      dy={dy}
      blink={blink}
      bodyTilt={-8 * lean}
      pivot={[150, 390]}
      armL={{t: [46 + Math.sin(f * 0.25) * 12, 306 + Math.cos(f * 0.25) * 10], bend: 1}}
      armR={{t: [250 + Math.sin(f * 0.12) * 16, 296], bend: -1}}
      headTilt={-4 * lean}
    />
  );
};
