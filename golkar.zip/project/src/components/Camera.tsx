import type {FC, ReactNode} from 'react';
import {AbsoluteFill} from 'remotion';
import {kfp, type Key, type Vec} from '../utils';

type Shake = {from: number; to: number; amp: number};

type Props = {
  f: number; // frame lokal beat
  children: ReactNode;
  zoom?: Key[];
  panX?: Key[];
  panY?: Key[];
  rotate?: Key[];
  origin?: Vec;
  shake?: Shake;
};

// Kamera 2D: zoom + pan + rotasi + camera shake deterministik (tanpa Math.random).
export const Camera: FC<Props> = ({f, children, zoom, panX, panY, rotate, origin = [540, 960], shake}) => {
  const z = zoom ? kfp(f, zoom) : 1;
  let px = panX ? kfp(f, panX) : 0;
  let py = panY ? kfp(f, panY) : 0;
  const rot = rotate ? kfp(f, rotate) : 0;
  if (shake && f >= shake.from && f <= shake.to) {
    const fall = 1 - (f - shake.from) / Math.max(1, shake.to - shake.from);
    px += Math.sin(f * 2.9) * shake.amp * fall;
    py += Math.cos(f * 3.7) * shake.amp * fall;
  }
  return (
    <AbsoluteFill
      style={{
        transform: `translate(${px}px, ${py}px) rotate(${rot}deg) scale(${z})`,
        transformOrigin: `${origin[0]}px ${origin[1]}px`,
      }}
    >
      {children}
    </AbsoluteFill>
  );
};
