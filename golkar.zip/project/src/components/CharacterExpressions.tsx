import type {FC} from 'react';
import type {Vec} from '../utils';

export type Expr =
  | 'smug'
  | 'thinking'
  | 'happy'
  | 'laughing'
  | 'shocked'
  | 'panic'
  | 'challenge'
  | 'sleepy'
  | 'flat';

const INK = '#111111';
const RED = '#8a1f2d';

// Alis: [x1,y1,x2,y2] kiri dan kanan layar.
const BROWS: Record<Expr, [[number, number, number, number], [number, number, number, number]]> = {
  smug: [[88, 124, 132, 120], [168, 112, 212, 100]],
  thinking: [[90, 114, 132, 108], [170, 128, 212, 120]],
  happy: [[90, 114, 132, 108], [168, 108, 210, 114]],
  laughing: [[92, 108, 130, 102], [170, 102, 208, 108]],
  shocked: [[88, 102, 132, 98], [168, 98, 212, 102]],
  panic: [[88, 102, 132, 94], [168, 94, 212, 102]],
  challenge: [[88, 112, 134, 130], [166, 130, 212, 112]],
  sleepy: [[92, 124, 132, 128], [168, 128, 208, 124]],
  flat: [[92, 122, 132, 122], [168, 122, 208, 122]],
};

const EYE_L: Vec = [112, 150];
const EYE_R: Vec = [188, 150];

const halfLidEye = (c: Vec, look: Vec, lid: number) => (
  <g>
    <path
      d={`M${c[0] - 15 + look[0]},${c[1] - lid + look[1]} L${c[0] + 15 + look[0]},${c[1] - lid + look[1]} A15,${13} 0 0 1 ${c[0] - 15 + look[0]},${c[1] - lid + look[1]} Z`}
      fill={INK}
    />
    <line
      x1={c[0] - 19 + look[0]}
      y1={c[1] - lid + look[1]}
      x2={c[0] + 19 + look[0]}
      y2={c[1] - lid + look[1]}
      stroke={INK}
      strokeWidth={6}
      strokeLinecap="round"
    />
  </g>
);

const roundEye = (c: Vec, look: Vec) => (
  <g>
    <circle cx={c[0] + look[0]} cy={c[1] + look[1]} r={12} fill={INK} />
    <circle cx={c[0] + look[0] + 4} cy={c[1] + look[1] - 4} r={3.5} fill="#fff" />
  </g>
);

const closedArc = (c: Vec) => (
  <path
    d={`M${c[0] - 16},${c[1] + 6} Q${c[0]},${c[1] - 14} ${c[0] + 16},${c[1] + 6}`}
    stroke={INK}
    strokeWidth={6}
    fill="none"
    strokeLinecap="round"
  />
);

const bigEye = (c: Vec, look: Vec) => (
  <g>
    <circle cx={c[0]} cy={c[1]} r={27} fill="#fff" stroke={INK} strokeWidth={6} />
    <circle cx={c[0] + look[0] * 0.7} cy={c[1] + look[1] * 0.7} r={8} fill={INK} />
  </g>
);

const eyes = (expr: Expr, look: Vec, blink: boolean) => {
  if (blink && (expr === 'smug' || expr === 'thinking' || expr === 'happy' || expr === 'challenge')) {
    return (
      <>
        {closedArc(EYE_L)}
        {closedArc(EYE_R)}
      </>
    );
  }
  switch (expr) {
    case 'smug':
      return (
        <>
          {halfLidEye(EYE_L, look, 3)}
          {halfLidEye(EYE_R, look, 3)}
        </>
      );
    case 'challenge':
      return (
        <>
          {halfLidEye(EYE_L, look, 5)}
          {halfLidEye(EYE_R, look, 5)}
        </>
      );
    case 'sleepy':
      return (
        <>
          {halfLidEye(EYE_L, look, 7)}
          {halfLidEye(EYE_R, look, 7)}
        </>
      );
    case 'flat':
      return (
        <>
          {halfLidEye(EYE_L, look, 4)}
          {halfLidEye(EYE_R, look, 4)}
        </>
      );
    case 'laughing':
      return (
        <>
          {closedArc(EYE_L)}
          {closedArc(EYE_R)}
        </>
      );
    case 'shocked':
    case 'panic':
      return (
        <>
          {bigEye(EYE_L, look)}
          {bigEye(EYE_R, look)}
        </>
      );
    default:
      return (
        <>
          {roundEye(EYE_L, look)}
          {roundEye(EYE_R, look)}
        </>
      );
  }
};

const mouth = (expr: Expr) => {
  switch (expr) {
    case 'smug':
      return <path d="M120,198 Q160,226 200,186" stroke={INK} strokeWidth={7} fill="none" strokeLinecap="round" />;
    case 'thinking':
      return <path d="M132,202 Q155,206 176,198" stroke={INK} strokeWidth={7} fill="none" strokeLinecap="round" />;
    case 'happy':
      return (
        <g>
          <path d="M114,188 Q150,240 188,188 Z" fill={RED} stroke={INK} strokeWidth={6} strokeLinejoin="round" />
          <ellipse cx={150} cy={218} rx={16} ry={8} fill="#ff8da1" />
        </g>
      );
    case 'laughing':
      return (
        <g>
          <path d="M104,182 Q150,256 196,182 Z" fill={RED} stroke={INK} strokeWidth={6} strokeLinejoin="round" />
          <ellipse cx={150} cy={222} rx={22} ry={11} fill="#ff8da1" />
        </g>
      );
    case 'shocked':
      return <ellipse cx={150} cy={212} rx={20} ry={30} fill={RED} stroke={INK} strokeWidth={6} />;
    case 'panic':
      return <ellipse cx={150} cy={214} rx={26} ry={36} fill={RED} stroke={INK} strokeWidth={6} />;
    case 'challenge':
      return <path d="M122,200 Q150,208 188,188" stroke={INK} strokeWidth={7} fill="none" strokeLinecap="round" />;
    case 'sleepy':
      return <path d="M134,204 Q150,212 168,204" stroke={INK} strokeWidth={6} fill="none" strokeLinecap="round" />;
    default:
      return <line x1={128} y1={206} x2={172} y2={206} stroke={INK} strokeWidth={7} strokeLinecap="round" />;
  }
};

export const Face: FC<{expr: Expr; look?: Vec; blink?: boolean}> = ({expr, look = [0, 0], blink = false}) => {
  const b = BROWS[expr];
  const showBrows = expr !== 'laughing' || true;
  return (
    <g transform="translate(0,10)">
      {eyes(expr, look, blink)}
      {showBrows && (
        <g stroke={INK} strokeWidth={7} strokeLinecap="round">
          <line x1={b[0][0]} y1={b[0][1]} x2={b[0][2]} y2={b[0][3]} />
          <line x1={b[1][0]} y1={b[1][1]} x2={b[1][2]} y2={b[1][3]} />
        </g>
      )}
      {mouth(expr)}
      {(expr === 'shocked' || expr === 'panic') && (
        <g>
          <path d="M240,112 Q252,140 240,152 Q226,140 240,112 Z" fill="#7ec8ff" stroke="#2a6aa8" strokeWidth={3} />
          <ellipse cx={90} cy={190} rx={14} ry={8} fill="#ff9aa8" opacity={0.7} />
          <ellipse cx={210} cy={190} rx={14} ry={8} fill="#ff9aa8" opacity={0.7} />
        </g>
      )}
      {expr === 'sleepy' && (
        <g>
          <ellipse cx={88} cy={188} rx={14} ry={8} fill="#ff9aa8" opacity={0.6} />
          <ellipse cx={212} cy={188} rx={14} ry={8} fill="#ff9aa8" opacity={0.6} />
        </g>
      )}
    </g>
  );
};
