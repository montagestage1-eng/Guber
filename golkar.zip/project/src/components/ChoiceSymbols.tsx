import type {FC} from 'react';
import type {Box} from '../data/layout';
import {GirlArt} from './GirlCharacter';
import {HEART_PATH} from './HeartEffects';

type P = {box: Box; scale?: number; dy?: number; rot?: number};

const wrap = (box: Box, scale: number, dy: number, rot: number) => ({
  position: 'absolute' as const,
  left: box.x,
  top: box.y,
  width: box.w,
  height: box.h,
  overflow: 'visible' as const,
  transform: `translateY(${dy}px) rotate(${rot}deg) scale(${scale})`,
  transformOrigin: '50% 50%',
});

// Simbol pilihan 1: siluet perempuan dengan hati.
export const SymbolGirl: FC<P> = ({box, scale = 1, dy = 0, rot = 0}) => (
  <svg style={wrap(box, scale, dy, rot)} viewBox="0 0 330 330">
    <defs>
      <clipPath id="sg-clip">
        <circle cx={165} cy={165} r={146} />
      </clipPath>
    </defs>
    <circle cx={165} cy={165} r={150} fill="#ffd1e1" stroke="#111" strokeWidth={8} />
    <g clipPath="url(#sg-clip)">
      <svg x={40} y={52} width={250} height={250} viewBox="0 10 200 200">
        <GirlArt expr="cheer" bow="#b3202e" />
      </svg>
    </g>
    <circle cx={165} cy={165} r={150} fill="none" stroke="#111" strokeWidth={8} />
    <g transform="translate(262 70) scale(0.55)">
      <path d={HEART_PATH} fill="#ff4d7e" stroke="#fff" strokeWidth={10} />
    </g>
  </svg>
);

// Simbol pilihan 2: kebun sawit dengan simbol uang.
export const SymbolPalm: FC<P> = ({box, scale = 1, dy = 0, rot = 0}) => (
  <svg style={wrap(box, scale, dy, rot)} viewBox="0 0 330 330">
    <circle cx={165} cy={165} r={150} fill="#ffe28a" stroke="#111" strokeWidth={8} />
    <path d="M150,290 Q156,200 154,130 L176,130 Q174,200 182,290 Z" fill="#7a5230" stroke="#111" strokeWidth={6} />
    {[-170, -140, -110, -70, -40, -10].map((a, i) => {
      const r = (a * Math.PI) / 180;
      return (
        <path
          key={i}
          d={`M165,128 Q${165 + Math.cos(r) * 60},${128 + Math.sin(r) * 60 - 20} ${165 + Math.cos(r) * 110},${128 + Math.sin(r) * 110 + 30}`}
          stroke="#2f7d32"
          strokeWidth={16}
          fill="none"
          strokeLinecap="round"
        />
      );
    })}
    <circle cx={165} cy={140} r={10} fill="#d8561f" stroke="#111" strokeWidth={3} />
    <circle cx={248} cy={236} r={44} fill="#f5c518" stroke="#7a5a00" strokeWidth={7} />
    <text x={248} y={250} textAnchor="middle" fontFamily="'Arial Black', Impact, sans-serif" fontWeight={900} fontSize={40} fill="#7a5a00">
      Rp
    </text>
  </svg>
);
