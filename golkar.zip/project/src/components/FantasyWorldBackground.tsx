import type {FC} from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {H, W} from '../data/layout';
import {rand} from '../utils';

// Dunia imajinatif pink, merah muda, dan emas (beat 02 dan panel atas beat 04).
export const FantasyWorldBackground: FC<{seed?: number; pulse?: number}> = ({seed = 7, pulse = 0}) => {
  const f = useCurrentFrame();
  const cx = 540;
  const cy = 760;
  return (
    <AbsoluteFill>
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`}>
        <defs>
          <radialGradient id="fw-g" cx="50%" cy="40%" r="80%">
            <stop offset="0%" stopColor="#ffe3ef" />
            <stop offset="35%" stopColor="#ff9fc3" />
            <stop offset="75%" stopColor="#e8457f" />
            <stop offset="100%" stopColor="#a3205a" />
          </radialGradient>
          <radialGradient id="fw-glow" cx="50%" cy="40%" r="40%">
            <stop offset="0%" stopColor="#ffd75a" stopOpacity={0.75} />
            <stop offset="100%" stopColor="#ffd75a" stopOpacity={0} />
          </radialGradient>
        </defs>
        <rect width={W} height={H} fill="url(#fw-g)" />
        <circle cx={cx} cy={cy} r={620 + pulse * 120} fill="url(#fw-glow)" />
        <g transform={`rotate(${-f * 0.3} ${cx} ${cy})`} opacity={0.22}>
          {Array.from({length: 20}).map((_, i) => {
            const a = (i / 20) * Math.PI * 2;
            const b = a + 0.1;
            return (
              <polygon
                key={i}
                points={`${cx},${cy} ${cx + Math.cos(a) * 2600},${cy + Math.sin(a) * 2600} ${cx + Math.cos(b) * 2600},${cy + Math.sin(b) * 2600}`}
                fill="#ffe08a"
              />
            );
          })}
        </g>
        {Array.from({length: 22}).map((_, i) => {
          const x = rand(seed * 50 + i) * W;
          const y0 = rand(seed * 50 + i + 30) * H;
          const r = 20 + rand(seed * 50 + i + 60) * 60;
          const y = (((y0 - f * (0.6 + rand(seed + i) * 0.8)) % (H + 200)) + H + 200) % (H + 200) - 100;
          return <circle key={i} cx={x} cy={y} r={r} fill="#ffffff" opacity={0.12} />;
        })}
        {Array.from({length: 14}).map((_, i) => {
          const x = rand(seed * 70 + i) * W;
          const y = rand(seed * 70 + i + 20) * H * 0.9;
          const tw = 0.5 + 0.5 * Math.sin(f * 0.18 + i * 1.7);
          const s = 10 + tw * 14;
          return (
            <path
              key={i}
              d={`M${x},${y - s} L${x + s * 0.25},${y - s * 0.25} L${x + s},${y} L${x + s * 0.25},${y + s * 0.25} L${x},${y + s} L${x - s * 0.25},${y + s * 0.25} L${x - s},${y} L${x - s * 0.25},${y - s * 0.25} Z`}
              fill="#fff6c8"
              opacity={0.5 + tw * 0.5}
            />
          );
        })}
      </svg>
    </AbsoluteFill>
  );
};
