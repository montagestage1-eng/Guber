import type {FC} from 'react';
import type {Box} from '../data/layout';

// Cewek kartun chibi (mengacu ke character sheet perempuan): rambut hitam panjang + poni,
// blus putih, pita merah, rok hitam, kaos kaki putih. Dipakai sebagai kerumunan.
export type GirlExpr = 'cheer' | 'love';

type Props = {
  box: Box;
  expr?: GirlExpr;
  flip?: boolean;
  dx?: number;
  dy?: number;
  scale?: number;
  bow?: string;
  opacity?: number;
  rot?: number;
};

const INK = '#2a1a1a';
const HAIR = '#2b1b1f';

export const GirlArt: FC<{expr: GirlExpr; bow: string}> = ({expr, bow}) => (
  <g>
    {/* rambut belakang */}
    <path
      d="M28,90 Q24,10 100,12 Q176,10 172,90 L184,236 Q150,262 100,250 Q50,262 16,236 Z"
      fill={HAIR}
      stroke={INK}
      strokeWidth={4}
      strokeLinejoin="round"
    />
    {/* kaki */}
    <g stroke={INK} strokeWidth={3}>
      <rect x={76} y={222} width={16} height={36} rx={6} fill="#fff4ee" />
      <rect x={108} y={222} width={16} height={36} rx={6} fill="#fff4ee" />
      <rect x={76} y={248} width={16} height={22} rx={6} fill="#ffffff" />
      <rect x={108} y={248} width={16} height={22} rx={6} fill="#ffffff" />
    </g>
    <ellipse cx={80} cy={276} rx={20} ry={9} fill="#1b1b1f" />
    <ellipse cx={122} cy={276} rx={20} ry={9} fill="#1b1b1f" />
    {/* rok */}
    <path d="M60,196 L140,196 L156,242 Q100,254 44,242 Z" fill="#1c1c22" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
    <path d="M78,200 L70,246 M100,200 L100,250 M122,200 L130,246" stroke="#34343e" strokeWidth={3} fill="none" />
    {/* blus */}
    <path d="M68,150 L132,150 L140,200 L60,200 Z" fill="#ffffff" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
    <path d="M100,150 L82,160 L88,176 L100,164 L112,176 L118,160 Z" fill={bow} stroke={INK} strokeWidth={3} strokeLinejoin="round" />
    <circle cx={100} cy={164} r={5} fill="#7a1018" />
    {/* lengan */}
    {expr === 'love' ? (
      <g stroke={INK} strokeWidth={3} fill="#fff4ee">
        <ellipse cx={80} cy={170} rx={10} ry={9} />
        <ellipse cx={120} cy={170} rx={10} ry={9} />
      </g>
    ) : (
      <g stroke={INK} strokeWidth={3} fill="#fff4ee">
        <path d="M68,154 L40,128 L48,120 L76,146 Z" />
        <path d="M132,154 L160,128 L152,120 L124,146 Z" />
      </g>
    )}
    {/* kepala */}
    <circle cx={100} cy={86} r={62} fill="#fff4ee" stroke={INK} strokeWidth={4} />
    {/* poni */}
    <path
      d="M38,84 Q34,20 100,22 Q166,20 162,84 Q150,50 130,60 Q114,44 100,62 Q86,44 70,60 Q50,50 38,84 Z"
      fill={HAIR}
      stroke={INK}
      strokeWidth={3}
      strokeLinejoin="round"
    />
    {/* wajah */}
    {expr === 'love' ? (
      <g stroke={INK} strokeWidth={4} fill="none" strokeLinecap="round">
        <path d="M66,98 Q76,86 86,98" />
        <path d="M114,98 Q124,86 134,98" />
      </g>
    ) : (
      <g>
        <ellipse cx={76} cy={96} rx={8} ry={10} fill={INK} />
        <ellipse cx={124} cy={96} rx={8} ry={10} fill={INK} />
        <circle cx={79} cy={92} r={3} fill="#fff" />
        <circle cx={127} cy={92} r={3} fill="#fff" />
      </g>
    )}
    <ellipse cx={58} cy={114} rx={12} ry={7} fill="#ff8aa0" opacity={0.75} />
    <ellipse cx={142} cy={114} rx={12} ry={7} fill="#ff8aa0" opacity={0.75} />
    <path d="M86,118 Q100,138 114,118 Z" fill="#b3202e" stroke={INK} strokeWidth={3} strokeLinejoin="round" />
  </g>
);

export const GirlCharacter: FC<Props> = ({
  box,
  expr = 'cheer',
  flip = false,
  dx = 0,
  dy = 0,
  scale = 1,
  bow = '#b3202e',
  opacity = 1,
  rot = 0,
}) => (
  <svg
    style={{
      position: 'absolute',
      left: box.x,
      top: box.y,
      width: box.w,
      height: box.h,
      overflow: 'visible',
      opacity,
      transform: `translate(${dx}px, ${dy}px) rotate(${rot}deg) scale(${flip ? -scale : scale}, ${scale})`,
      transformOrigin: '50% 100%',
    }}
    viewBox="0 0 200 300"
    preserveAspectRatio="xMidYMid meet"
  >
    <GirlArt expr={expr} bow={bow} />
  </svg>
);
