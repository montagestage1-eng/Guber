import type {FC} from 'react';
import {useCurrentFrame} from 'remotion';
import {H, W, type Box} from '../data/layout';
import {rand} from '../utils';

export const HEART_PATH = 'M0,-12 C-34,-48 -80,-6 0,56 C80,-6 34,-48 0,-12 Z';

type Props = {
  seed?: number;
  count?: number;
  area?: Box;
  color?: string;
  speed?: number;
  start?: number;
};

// Hati mengambang naik dengan goyangan; posisi sepenuhnya ditentukan frame + seed.
export const HeartEffects: FC<Props> = ({
  seed = 3,
  count = 14,
  area = {x: 0, y: 0, w: W, h: H},
  color = '#ff4d7e',
  speed = 1,
  start = 0,
}) => {
  const f = useCurrentFrame() - start;
  if (f < 0) return null;
  const period = 300;
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0, pointerEvents: 'none'}}>
      {Array.from({length: count}).map((_, i) => {
        const r1 = rand(seed * 31 + i);
        const r2 = rand(seed * 31 + i + 11);
        const r3 = rand(seed * 31 + i + 23);
        const p = (((f * speed * (0.6 + r3 * 0.7) + r1 * period) % period) + period) % period / period;
        const x = area.x + r1 * area.w + Math.sin(f * 0.07 + i * 2) * 22;
        const y = area.y + area.h - p * area.h;
        const s = 0.28 + r2 * 0.4;
        const pop = Math.min(1, f / 8 + 0.2);
        return (
          <g key={i} transform={`translate(${x} ${y}) rotate(${Math.sin(f * 0.05 + i) * 14}) scale(${s * pop})`} opacity={Math.sin(p * Math.PI)}>
            <path d={HEART_PATH} fill={color} stroke="#ffffff" strokeWidth={6} />
            <ellipse cx={-22} cy={-10} rx={9} ry={5} fill="#ffffff" opacity={0.7} transform="rotate(-30 -22 -10)" />
          </g>
        );
      })}
    </svg>
  );
};
