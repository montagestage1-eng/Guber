import type {FC} from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {H, W} from '../data/layout';
import {rand} from '../utils';

// Latar dramatis polos-berdimensi untuk beat 01 (biru keunguan) dan beat 05 (merah).
export const HomeBackground: FC<{palette?: 'blue' | 'red'; seed?: number}> = ({palette = 'blue', seed = 1}) => {
  const f = useCurrentFrame();
  const pal =
    palette === 'red'
      ? {a: '#ff6a55', b: '#c3162f', c: '#4a0818', id: 'hbr'}
      : {a: '#7d6cff', b: '#3d2fa6', c: '#120f36', id: 'hbb'};
  const cx = 540;
  const cy = 780;
  return (
    <AbsoluteFill>
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`}>
        <defs>
          <radialGradient id={`${pal.id}-g`} cx="50%" cy="41%" r="75%">
            <stop offset="0%" stopColor={pal.a} />
            <stop offset="45%" stopColor={pal.b} />
            <stop offset="100%" stopColor={pal.c} />
          </radialGradient>
          <radialGradient id={`${pal.id}-v`} cx="50%" cy="50%" r="72%">
            <stop offset="60%" stopColor="#000" stopOpacity={0} />
            <stop offset="100%" stopColor="#000" stopOpacity={0.55} />
          </radialGradient>
        </defs>
        <rect width={W} height={H} fill={`url(#${pal.id}-g)`} />
        <g transform={`rotate(${f * 0.25} ${cx} ${cy})`} opacity={0.14}>
          {Array.from({length: 18}).map((_, i) => {
            const a = (i / 18) * Math.PI * 2;
            const b = a + 0.12;
            return (
              <polygon
                key={i}
                points={`${cx},${cy} ${cx + Math.cos(a) * 2600},${cy + Math.sin(a) * 2600} ${cx + Math.cos(b) * 2600},${cy + Math.sin(b) * 2600}`}
                fill="#ffffff"
              />
            );
          })}
        </g>
        {Array.from({length: 26}).map((_, i) => {
          const x = rand(seed * 100 + i) * W;
          const base = rand(seed * 100 + i + 40) * H;
          const sp = 0.4 + rand(seed * 100 + i + 80) * 1.2;
          const y = (((base - f * sp * 2) % H) + H) % H;
          const r = 3 + rand(seed * 100 + i + 120) * 7;
          return <circle key={i} cx={x} cy={y} r={r} fill="#ffffff" opacity={0.28} />;
        })}
        <rect width={W} height={H} fill={`url(#${pal.id}-v)`} />
      </svg>
    </AbsoluteFill>
  );
};
