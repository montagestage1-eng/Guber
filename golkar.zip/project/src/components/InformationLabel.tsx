import type {FC} from 'react';
import type {Box} from '../data/layout';

// Papan di dalam lingkungan cerita (bagian dunia, BUKAN header video).
export const InformationLabel: FC<{box: Box; line1: string; line2: string; sway?: number}> = ({
  box,
  line1,
  line2,
  sway = 0,
}) => (
  <svg
    style={{
      position: 'absolute',
      left: box.x,
      top: box.y,
      width: box.w,
      height: box.h,
      overflow: 'visible',
      transform: `rotate(${sway}deg)`,
      transformOrigin: '50% 100%',
    }}
    viewBox="0 0 460 280"
  >
    <rect x={70} y={150} width={26} height={130} fill="#6b4524" stroke="#2a160c" strokeWidth={5} />
    <rect x={364} y={150} width={26} height={130} fill="#6b4524" stroke="#2a160c" strokeWidth={5} />
    <rect x={10} y={10} width={440} height={170} rx={12} fill="#c9a06a" stroke="#2a160c" strokeWidth={7} />
    <path d="M20,60 L440,60 M20,120 L440,120" stroke="#a27a46" strokeWidth={3} />
    <circle cx={32} cy={30} r={6} fill="#4a2a18" />
    <circle cx={428} cy={30} r={6} fill="#4a2a18" />
    <circle cx={32} cy={160} r={6} fill="#4a2a18" />
    <circle cx={428} cy={160} r={6} fill="#4a2a18" />
    <text x={230} y={86} textAnchor="middle" fontFamily="'Arial Black', Impact, sans-serif" fontWeight={900} fontSize={58} fill="#3a2010">
      {line1}
    </text>
    <text x={230} y={148} textAnchor="middle" fontFamily="'Arial Black', Impact, sans-serif" fontWeight={900} fontSize={48} fill="#3a2010">
      {line2}
    </text>
  </svg>
);
