import type {FC} from 'react';
import type {Box} from '../data/layout';
import {Face, type Expr} from './CharacterExpressions';
import {ik, pts, type Vec} from '../utils';

export type Pose = 'stand' | 'sit' | 'lounge' | 'run';
export type Crop = 'full' | 'mid' | 'upper' | 'head';
export type ArmSpec = {t: Vec; bend?: 1 | -1; hs?: number};
export type LegSpec = {l: Vec; r: Vec};

const INK = '#111111';
const HOODIE = '#d9dce1';
const HOODIE_DARK = '#b9bdc6';
const HAIR = '#4a2a18';
const HAIR_LINE = '#2a160c';

const CROPS: Record<Crop, string> = {
  full: '-20 -20 340 550',
  mid: '-30 -20 360 490',
  upper: '-10 -15 320 395',
  head: '20 -15 260 265',
};

export const LEGS: Record<'stand' | 'sit' | 'lounge', LegSpec> = {
  stand: {l: [116, 506], r: [184, 506]},
  sit: {l: [205, 486], r: [250, 498]},
  lounge: {l: [262, 372], r: [236, 452]},
};

export const runLegs = (phase: number): LegSpec => {
  const s = Math.sin(phase);
  const c = Math.cos(phase);
  return {
    l: [150 + 58 * s, 506 - 26 * Math.max(0, c)],
    r: [150 - 58 * s, 506 - 26 * Math.max(0, -c)],
  };
};

export type CharacterProps = {
  box: Box;
  expr: Expr;
  crop?: Crop;
  pose?: Pose;
  runPhase?: number;
  legs?: LegSpec;
  armL?: ArmSpec;
  armR?: ArmSpec;
  suit?: boolean;
  glasses?: number; // 0 = tidak ada, 1 = terpasang
  crown?: number | null; // null = tanpa mahkota, angka = offset Y (0 = terpasang)
  fan?: boolean;
  flip?: boolean;
  headTilt?: number;
  bodyTilt?: number;
  pivot?: Vec;
  look?: Vec;
  blink?: boolean;
  hairSway?: number;
  dx?: number;
  dy?: number;
  sx?: number;
  sy?: number;
  shadow?: boolean;
};

const HIP_L: Vec = [128, 390];
const HIP_R: Vec = [172, 390];
const SH_L: Vec = [96, 262];
const SH_R: Vec = [204, 262];

const Leg: FC<{hip: Vec; foot: Vec; bend: 1 | -1}> = ({hip, foot, bend}) => {
  const {elbow: knee, hand: ankle} = ik(hip, foot, 60, 60, bend);
  return (
    <g>
      <polyline points={pts(hip, knee, ankle)} stroke={INK} strokeWidth={12} fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <ellipse cx={ankle[0] + (foot[0] >= hip[0] ? 8 : -8)} cy={ankle[1] + 4} rx={26} ry={12} fill={INK} />
    </g>
  );
};

const Arm: FC<{s: Vec; spec: ArmSpec; suit: boolean; fan: boolean}> = ({s, spec, suit, fan}) => {
  const {elbow, hand} = ik(s, spec.t, 82, 82, spec.bend ?? 1);
  const sleeveEnd: Vec = [s[0] + (elbow[0] - s[0]) * 0.62, s[1] + (elbow[1] - s[1]) * 0.62];
  const hs = spec.hs ?? 1;
  return (
    <g>
      <polyline points={pts(s, elbow, hand)} stroke={INK} strokeWidth={11} fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <line x1={s[0]} y1={s[1]} x2={sleeveEnd[0]} y2={sleeveEnd[1]} stroke={INK} strokeWidth={40} strokeLinecap="round" />
      <line
        x1={s[0]}
        y1={s[1]}
        x2={sleeveEnd[0]}
        y2={sleeveEnd[1]}
        stroke={suit ? '#23232b' : HOODIE}
        strokeWidth={30}
        strokeLinecap="round"
      />
      {fan && (
        <g transform={`translate(${hand[0]},${hand[1]})`}>
          {[-2, -1, 0, 1, 2].map((i) => (
            <rect
              key={i}
              x={0}
              y={-24}
              width={104}
              height={48}
              rx={6}
              fill="#f4a3b6"
              stroke="#7a2236"
              strokeWidth={4}
              transform={`rotate(${-80 + i * 17})`}
            />
          ))}
        </g>
      )}
      <circle cx={hand[0]} cy={hand[1]} r={14 * hs} fill={INK} />
      {hs > 1.5 && (
        <line
          x1={hand[0]}
          y1={hand[1]}
          x2={hand[0] + ((hand[0] - elbow[0]) / (Math.hypot(hand[0] - elbow[0], hand[1] - elbow[1]) || 1)) * 46}
          y2={hand[1] + ((hand[1] - elbow[1]) / (Math.hypot(hand[0] - elbow[0], hand[1] - elbow[1]) || 1)) * 46}
          stroke={INK}
          strokeWidth={15}
          strokeLinecap="round"
        />
      )}
    </g>
  );
};

export const MainCharacter: FC<CharacterProps> = (p) => {
  const {
    box,
    expr,
    crop = 'full',
    pose = 'stand',
    suit = false,
    glasses = 0,
    crown = null,
    fan = false,
    flip = false,
    headTilt = 0,
    bodyTilt = 0,
    pivot = [150, 505],
    look = [0, 0],
    blink = false,
    hairSway = 0,
    dx = 0,
    dy = 0,
    sx = 1,
    sy = 1,
    shadow = true,
  } = p;

  const legs: LegSpec = p.legs ?? (pose === 'run' ? runLegs(p.runPhase ?? 0) : LEGS[pose]);
  const armL: ArmSpec = p.armL ?? {t: [78, 402], bend: 1};
  const armR: ArmSpec = p.armR ?? {t: [222, 402], bend: -1};
  const legBend = (hip: Vec, foot: Vec, side: 'l' | 'r'): 1 | -1 => {
    if (pose === 'stand') return side === 'l' ? 1 : -1;
    return foot[0] >= hip[0] ? -1 : 1;
  };
  const armLFront = armL.t[1] < 250;
  const armRFront = armR.t[1] < 250;

  return (
    <svg
      style={{
        position: 'absolute',
        left: box.x,
        top: box.y,
        width: box.w,
        height: box.h,
        overflow: 'visible',
        transform: `translate(${dx}px, ${dy}px) scale(${(flip ? -1 : 1) * sx}, ${sy})`,
        transformOrigin: '50% 100%',
      }}
      viewBox={CROPS[crop]}
      preserveAspectRatio="xMidYMid meet"
    >
      {shadow && <ellipse cx={150} cy={514} rx={96} ry={12} fill="rgba(0,0,0,0.20)" />}
      <g transform={`rotate(${bodyTilt} ${pivot[0]} ${pivot[1]})`}>
        {/* kaki */}
        <Leg hip={HIP_L} foot={legs.l} bend={legBend(HIP_L, legs.l, 'l')} />
        <Leg hip={HIP_R} foot={legs.r} bend={legBend(HIP_R, legs.r, 'r')} />

        {/* lengan belakang (tidak terangkat) */}
        {!armLFront && <Arm s={SH_L} spec={armL} suit={suit} fan={fan} />}
        {!armRFront && <Arm s={SH_R} spec={armR} suit={suit} fan={false} />}

        {/* hoodie */}
        <path
          d="M95,236 Q150,214 205,236 L216,392 Q150,408 84,392 Z"
          fill={HOODIE}
          stroke={INK}
          strokeWidth={6}
          strokeLinejoin="round"
        />
        <path d="M84,392 Q150,408 216,392 L214,372 Q150,388 86,372 Z" fill={HOODIE_DARK} opacity={0.55} />
        <ellipse cx={150} cy={240} rx={62} ry={22} fill={HOODIE_DARK} stroke={INK} strokeWidth={5} />
        <path d="M128,226 Q150,240 172,226" stroke={INK} strokeWidth={4} fill="none" />
        <g stroke="#ffffff" strokeWidth={6} strokeLinecap="round">
          <line x1={134} y1={252} x2={131} y2={312} />
          <line x1={166} y1={252} x2={169} y2={312} />
        </g>
        <g stroke={INK} strokeWidth={2} fill="#fff">
          <circle cx={131} cy={316} r={5} />
          <circle cx={169} cy={316} r={5} />
        </g>
        <path
          d="M112,344 Q150,334 188,344 L194,376 Q150,386 106,376 Z"
          fill={HOODIE}
          stroke={INK}
          strokeWidth={4}
          strokeLinejoin="round"
        />

        {/* jas */}
        {suit && (
          <g>
            <path
              d="M88,236 L128,244 L150,300 L172,244 L212,236 L224,396 L76,396 Z"
              fill="#16161b"
              stroke={INK}
              strokeWidth={5}
              strokeLinejoin="round"
            />
            <path d="M128,244 L150,300 L172,244 Z" fill="#f4f4f6" stroke={INK} strokeWidth={3} />
            <path d="M144,262 L156,262 L162,322 L150,340 L138,322 Z" fill="#b3122a" stroke={INK} strokeWidth={3} />
            <rect x={142} y={284} width={16} height={5} rx={2} fill="#f5c518" />
            <circle cx={104} cy={378} r={5} fill="#f5c518" />
            <circle cx={196} cy={378} r={5} fill="#f5c518" />
            <path d="M128,244 L110,300 M172,244 L190,300" stroke="#3b3b45" strokeWidth={4} fill="none" />
          </g>
        )}

        {/* kepala */}
        <g transform={`rotate(${headTilt} 150 225)`}>
          <circle cx={150} cy={140} r={92} fill="#ffffff" stroke={INK} strokeWidth={7} />
          <g transform={`rotate(${hairSway} 150 100)`}>
            <path
              d="M64,128 L52,76 L86,92 L84,28 L118,66 L132,-8 L156,62 L190,14 L198,70 L236,44 L236,128 Q150,56 64,128 Z"
              fill={HAIR}
              stroke={HAIR_LINE}
              strokeWidth={5}
              strokeLinejoin="round"
            />
            <path d="M96,92 L112,60 M150,60 L160,22 M196,78 L212,56" stroke="#6b4026" strokeWidth={5} strokeLinecap="round" fill="none" />
          </g>
          <Face expr={expr} look={look} blink={blink} />
          {glasses > 0 && (
            <g transform={`translate(0 ${-(1 - glasses) * 90})`} opacity={Math.min(1, glasses * 3)}>
              <rect x={84} y={134} width={56} height={40} rx={14} fill="#0d0d0d" stroke={INK} strokeWidth={4} />
              <rect x={160} y={134} width={56} height={40} rx={14} fill="#0d0d0d" stroke={INK} strokeWidth={4} />
              <path d="M140,148 Q150,142 160,148" stroke={INK} strokeWidth={5} fill="none" />
              <line x1={84} y1={146} x2={60} y2={140} stroke={INK} strokeWidth={5} strokeLinecap="round" />
              <line x1={216} y1={146} x2={240} y2={140} stroke={INK} strokeWidth={5} strokeLinecap="round" />
              <path d="M92,142 L104,142 M168,142 L180,142" stroke="#fff" strokeWidth={3} strokeLinecap="round" opacity={0.6} />
            </g>
          )}
          {crown !== null && (
            <g transform={`translate(0 ${crown + 18})`}>
              <path
                d="M78,36 L92,-34 L124,8 L150,-46 L176,8 L208,-34 L222,36 Z"
                fill="#f5c518"
                stroke="#7a5a00"
                strokeWidth={5}
                strokeLinejoin="round"
              />
              <rect x={78} y={26} width={144} height={14} rx={5} fill="#e0a800" stroke="#7a5a00" strokeWidth={4} />
              <circle cx={150} cy={-20} r={7} fill="#d62839" stroke="#7a5a00" strokeWidth={3} />
              <circle cx={92} cy={-18} r={5} fill="#2e86de" stroke="#7a5a00" strokeWidth={3} />
              <circle cx={208} cy={-18} r={5} fill="#2e86de" stroke="#7a5a00" strokeWidth={3} />
            </g>
          )}
        </g>

        {/* lengan di depan kepala (mis. tangan di dagu) */}
        {armLFront && <Arm s={SH_L} spec={armL} suit={suit} fan={fan} />}
        {armRFront && <Arm s={SH_R} spec={armR} suit={suit} fan={false} />}
      </g>
    </svg>
  );
};
