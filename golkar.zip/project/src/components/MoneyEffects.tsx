import type {FC} from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {H, W} from '../data/layout';
import {rand, type Vec} from '../utils';

type Props = {
  start: number;
  count?: number;
  origin?: Vec;
  seed?: number;
  gravity?: number;
  coins?: boolean;
};

const Bill: FC = () => (
  <g>
    <rect x={-40} y={-20} width={80} height={40} rx={5} fill="#f4a3b6" stroke="#7a2236" strokeWidth={4} />
    <circle cx={0} cy={0} r={12} fill="#fff1c9" stroke="#7a2236" strokeWidth={3} />
    <text x={0} y={5} textAnchor="middle" fontFamily="Arial, sans-serif" fontWeight={900} fontSize={14} fill="#7a2236">
      Rp
    </text>
  </g>
);

// Uang pop + beterbangan ringan (mode lembaran) atau koin berkilau (coins = true).
export const MoneyEffects: FC<Props> = ({start, count = 16, origin = [540, 1000], seed = 5, gravity = 600, coins = false}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const lf = f - start;
  if (lf < 0) return null;
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0, pointerEvents: 'none'}}>
      {Array.from({length: count}).map((_, i) => {
        const delay = Math.floor(rand(seed + i * 7) * 14);
        const t = (lf - delay) / fps;
        if (t < 0) return null;
        const ang = (rand(seed + i * 7 + 1) - 0.5) * Math.PI * 0.95 - Math.PI / 2;
        const sp = 380 + rand(seed + i * 7 + 2) * 520;
        const x = origin[0] + Math.cos(ang) * sp * t + Math.sin(lf * 0.08 + i) * 14;
        const y = origin[1] + Math.sin(ang) * sp * t + 0.5 * gravity * t * t;
        const sc = spring({frame: lf - delay, fps, config: {damping: 9, stiffness: 220}});
        const rot = (rand(seed + i * 7 + 3) - 0.5) * 400 * t;
        const out = y > H + 80 ? 0 : 1;
        return (
          <g key={i} transform={`translate(${x} ${y}) rotate(${rot}) scale(${sc * (coins ? 0.5 : 1)})`} opacity={out}>
            {coins ? (
              <g>
                <circle r={22} fill="#f5c518" stroke="#7a5a00" strokeWidth={4} />
                <circle r={13} fill="none" stroke="#b88a00" strokeWidth={3} />
                <path d="M-6,-4 L0,-14 L6,-4 L16,0 L6,4 L0,14 L-6,4 L-16,0 Z" fill="#fff6c8" opacity={0.7} />
              </g>
            ) : (
              <Bill />
            )}
          </g>
        );
      })}
    </svg>
  );
};
