import type {FC} from 'react';
import {H, W} from '../data/layout';
import {clamp, ease, rand} from '../utils';
import {HEART_PATH} from './HeartEffects';

const SVG_STYLE = {position: 'absolute', left: 0, top: 0, pointerEvents: 'none'} as const;

// Kilat satu warna yang meredup linear (frame lokal `f`).
export const Flash: FC<{f: number; from: number; dur: number; color?: string}> = ({f, from, dur, color = '#ffffff'}) => {
  const o = 1 - (f - from) / dur;
  if (f < from || o <= 0) return null;
  return <div style={{position: 'absolute', inset: 0, background: color, opacity: clamp(o, 0, 1)}} />;
};

// Garis kecepatan horizontal.
export const SpeedLines: FC<{f: number; from: number; dur: number; seed?: number; region?: [number, number]}> = ({
  f,
  from,
  dur,
  seed = 2,
  region = [0, H],
}) => {
  if (f < from || f > from + dur) return null;
  const sh = ((f - from) * 90) % W;
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={SVG_STYLE}>
      {Array.from({length: 16}).map((_, i) => {
        const y = region[0] + rand(seed + i) * (region[1] - region[0]);
        const len = 220 + rand(seed + i + 40) * 380;
        const x = (((rand(seed + i + 80) * W + sh * (0.7 + rand(seed + i) * 0.8)) % (W + len)) + W + len) % (W + len) - len;
        return <line key={i} x1={x} y1={y} x2={x + len} y2={y} stroke="#ffffff" strokeWidth={6} strokeLinecap="round" opacity={0.55} />;
      })}
    </svg>
  );
};

// Sapuan diagonal (split wipe). mode 'in': menutup layar; 'out': membuka. Dipakai 2 sisi batas beat.
export const DiagWipe: FC<{f: number; from: number; dur: number; mode: 'in' | 'out'; color?: string; flip?: boolean}> = ({
  f,
  from,
  dur,
  mode,
  color = '#ffffff',
  flip = false,
}) => {
  const t = (f - from) / dur;
  if (t < 0 || t > 1) return null;
  const p = ease(clamp(t, 0, 1));
  const x0 = mode === 'in' ? -2000 + p * 1400 : -600 + p * 1700;
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{...SVG_STYLE, transform: flip ? 'scaleX(-1)' : undefined}}>
      <polygon points={`${x0 + 300},0 ${x0 + 2300},0 ${x0 + 2000},${H} ${x0},${H}`} fill={color} />
    </svg>
  );
};

// Letupan lingkaran + ikon radial. 'out' = membesar menutup layar, 'in' = mengecil membuka.
export const BurstOverlay: FC<{f: number; from: number; dur: number; mode: 'out' | 'in'; color: string; icon: 'heart' | 'coin'}> = ({
  f,
  from,
  dur,
  mode,
  color,
  icon,
}) => {
  const t = (f - from) / dur;
  if (t < 0 || t > 1) return null;
  const p = ease(clamp(t, 0, 1));
  const q = mode === 'out' ? p : 1 - p;
  const r = q * 1700;
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={SVG_STYLE}>
      <circle cx={540} cy={900} r={r} fill={color} />
      {Array.from({length: 14}).map((_, i) => {
        const a = (i / 14) * Math.PI * 2;
        const d = r * 0.85;
        const x = 540 + Math.cos(a) * d;
        const y = 900 + Math.sin(a) * d;
        return (
          <g key={i} transform={`translate(${x} ${y}) rotate(${i * 25}) scale(${0.6 + (i % 3) * 0.25})`}>
            {icon === 'heart' ? (
              <path d={HEART_PATH} fill="#ff4d7e" stroke="#fff" strokeWidth={6} />
            ) : (
              <g>
                <circle r={34} fill="#f5c518" stroke="#7a5a00" strokeWidth={5} />
                <circle r={20} fill="none" stroke="#b88a00" strokeWidth={4} />
              </g>
            )}
          </g>
        );
      })}
    </svg>
  );
};

// Kilau bintang kecil berkedip.
export const Sparkle: FC<{f: number; x: number; y: number; size?: number; phase?: number; color?: string}> = ({
  f,
  x,
  y,
  size = 26,
  phase = 0,
  color = '#fff6c8',
}) => {
  const tw = 0.5 + 0.5 * Math.sin(f * 0.25 + phase);
  const s = size * (0.4 + tw * 0.9);
  return (
    <path
      d={`M${x},${y - s} L${x + s * 0.25},${y - s * 0.25} L${x + s},${y} L${x + s * 0.25},${y + s * 0.25} L${x},${y + s} L${x - s * 0.25},${y + s * 0.25} L${x - s},${y} L${x - s * 0.25},${y - s * 0.25} Z`}
      fill={color}
      opacity={0.5 + tw * 0.5}
    />
  );
};

// Tanda tanya / seru bergaya komik sebagai ikon besar (teks SVG tebal).
export const ComicMark: FC<{x: number; y: number; w: number; h: number; char: '?' | '!!'; color: string; scale?: number; rot?: number}> = ({
  x,
  y,
  w,
  h,
  char,
  color,
  scale = 1,
  rot = 0,
}) => (
  <svg
    style={{position: 'absolute', left: x, top: y, width: w, height: h, overflow: 'visible', transform: `rotate(${rot}deg) scale(${scale})`, transformOrigin: '50% 80%'}}
    viewBox="0 0 100 130"
  >
    <text
      x={50}
      y={104}
      textAnchor="middle"
      fontFamily="'Arial Black', Impact, sans-serif"
      fontWeight={900}
      fontSize={char === '?' ? 130 : 110}
      fill={color}
      stroke="#111"
      strokeWidth={6}
      paintOrder="stroke"
    >
      {char}
    </text>
  </svg>
);
