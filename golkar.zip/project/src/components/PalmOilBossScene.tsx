import type {FC, ReactNode} from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {H, LAYOUT, W} from '../data/layout';
import {PalmOilPlantation} from './PalmOilPlantation';
import {InformationLabel} from './InformationLabel';

const INK = '#2a160c';

const Fruit: FC<{cx: number; cy: number; r?: number}> = ({cx, cy, r = 14}) => (
  <g>
    <circle cx={cx} cy={cy} r={r} fill="#d8561f" stroke="#5a1c08" strokeWidth={3} />
    <circle cx={cx - r * 0.3} cy={cy - r * 0.3} r={r * 0.28} fill="#ffb27a" />
  </g>
);

const Bunch: FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <ellipse cx={0} cy={6} rx={78} ry={14} fill="rgba(0,0,0,0.18)" />
    <path d="M-70,0 Q0,-120 70,0 Z" fill="#5a2f14" stroke={INK} strokeWidth={5} />
    {[[-40, -22], [-12, -44], [18, -50], [46, -24], [0, -18], [-26, -6], [28, -4], [-52, -2], [58, -4], [4, -70]].map((p, i) => (
      <Fruit key={i} cx={p[0]} cy={p[1]} r={17} />
    ))}
  </g>
);

const MoneyStack: FC<{x: number; y: number; w: number; rows: number}> = ({x, y, w, rows}) => (
  <g>
    {Array.from({length: rows}).map((_, i) => {
      const off = (i % 2) * 10 - 5;
      return (
        <g key={i}>
          <rect x={x + off} y={y - (i + 1) * 36} width={w} height={34} rx={4} fill="#f4a3b6" stroke="#7a2236" strokeWidth={4} />
          <rect x={x + off + w * 0.42} y={y - (i + 1) * 36} width={w * 0.16} height={34} fill="#fff1c9" stroke="#7a2236" strokeWidth={3} />
        </g>
      );
    })}
  </g>
);

const Sack: FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <ellipse cx={0} cy={6} rx={72} ry={12} fill="rgba(0,0,0,0.2)" />
    <path d="M-62,0 Q-80,-90 -34,-150 L-20,-170 L20,-170 L34,-150 Q80,-90 62,0 Z" fill="#c9a56a" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
    <path d="M-30,-150 L30,-150 L24,-166 L-24,-166 Z" fill="#a27a46" stroke={INK} strokeWidth={4} />
    <path d="M-34,-150 Q0,-140 34,-150" stroke="#7a2236" strokeWidth={6} fill="none" />
    <text x={0} y={-62} textAnchor="middle" fontFamily="'Arial Black', Impact, sans-serif" fontSize={46} fontWeight={900} fill="#2e7d32" stroke={INK} strokeWidth={2}>
      Rp
    </text>
  </g>
);

const Truck: FC<{box: {x: number; y: number; w: number; h: number}}> = ({box}) => (
  <svg style={{position: 'absolute', left: box.x, top: box.y, width: box.w, height: box.h, overflow: 'visible'}} viewBox="0 0 360 220">
    <ellipse cx={180} cy={212} rx={170} ry={10} fill="rgba(0,0,0,0.22)" />
    <rect x={10} y={150} width={330} height={20} fill="#3a3a42" stroke={INK} strokeWidth={4} />
    <path d="M18,60 L236,60 L236,150 L18,150 Z" fill="#8a5a2b" stroke={INK} strokeWidth={5} />
    <path d="M18,70 Q127,10 236,70 Z" fill="#6b3d1c" stroke={INK} strokeWidth={4} />
    {[[50, 52], [86, 36], [124, 28], [160, 36], [196, 50], [70, 66], [120, 60], [180, 64], [30, 70], [220, 66]].map((p, i) => (
      <Fruit key={i} cx={p[0]} cy={p[1]} r={17} />
    ))}
    <path d="M244,80 L300,80 L340,116 L340,150 L244,150 Z" fill="#f2b705" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
    <path d="M254,90 L296,90 L322,116 L254,116 Z" fill="#bfe6ff" stroke={INK} strokeWidth={4} />
    {[[70, 184], [170, 184], [290, 184]].map((p, i) => (
      <g key={i}>
        <circle cx={p[0]} cy={p[1]} r={32} fill="#16161b" stroke="#000" strokeWidth={4} />
        <circle cx={p[0]} cy={p[1]} r={14} fill="#9a9aa6" stroke="#000" strokeWidth={3} />
      </g>
    ))}
  </svg>
);

const Excavator: FC<{box: {x: number; y: number; w: number; h: number}; angle: number}> = ({box, angle}) => (
  <svg style={{position: 'absolute', left: box.x, top: box.y, width: box.w, height: box.h, overflow: 'visible'}} viewBox="0 0 280 200">
    <ellipse cx={130} cy={196} rx={120} ry={9} fill="rgba(0,0,0,0.22)" />
    <rect x={20} y={150} width={200} height={40} rx={20} fill="#2c2c34" stroke="#000" strokeWidth={4} />
    <rect x={56} y={86} width={110} height={66} rx={8} fill="#f2b705" stroke={INK} strokeWidth={5} />
    <rect x={70} y={96} width={52} height={36} rx={5} fill="#bfe6ff" stroke={INK} strokeWidth={4} />
    <g transform={`rotate(${angle} 150 100)`}>
      <polyline points="150,100 236,38 266,104" stroke={INK} strokeWidth={22} fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <polyline points="150,100 236,38 266,104" stroke="#f2b705" strokeWidth={14} fill="none" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M254,100 L282,100 L274,130 L256,130 Z" fill="#6b6b78" stroke={INK} strokeWidth={4} />
    </g>
  </svg>
);

const ThroneBack: FC = () => (
  <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
    <ellipse cx={540} cy={1396} rx={380} ry={30} fill="rgba(0,0,0,0.25)" />
    <path d="M300,1330 L300,860 Q300,770 540,760 Q780,770 780,860 L780,1330 Z" fill="#8b1e24" stroke="#c99a1a" strokeWidth={10} strokeLinejoin="round" />
    <path d="M330,1320 L330,880 Q330,810 540,800 Q750,810 750,880 L750,1320 Z" fill="#a62830" stroke="#6d1218" strokeWidth={5} />
    <circle cx={540} cy={800} r={20} fill="#f5c518" stroke="#7a5a00" strokeWidth={5} />
    <circle cx={330} cy={870} r={13} fill="#f5c518" stroke="#7a5a00" strokeWidth={4} />
    <circle cx={750} cy={870} r={13} fill="#f5c518" stroke="#7a5a00" strokeWidth={4} />
  </svg>
);

const ThroneFront: FC = () => (
  <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
    <rect x={290} y={1290} width={500} height={90} rx={20} fill="#c0272f" stroke="#c99a1a" strokeWidth={8} />
    <rect x={260} y={1180} width={64} height={200} rx={20} fill="#8b1e24" stroke="#c99a1a" strokeWidth={8} />
    <rect x={756} y={1180} width={64} height={200} rx={20} fill="#8b1e24" stroke="#c99a1a" strokeWidth={8} />
    <rect x={240} y={1380} width={600} height={30} rx={10} fill="#6b4524" stroke={INK} strokeWidth={5} />
  </svg>
);

type Props = {
  children?: ReactNode;
  tx?: number;
  ty?: number;
  scale?: number;
  scroll?: number;
  excAngle?: number;
  truckDx?: number;
};

// Perkebunan + kantor/area bos: singgasana, uang, karung, tandan, truk, alat berat, papan.
// `children` (karakter bos) disisipkan di antara sandaran dan bagian depan singgasana.
export const PalmOilBossScene: FC<Props> = ({children, tx = 0, ty = 0, scale = 1, scroll = 0, excAngle, truckDx = 0}) => {
  const f = useCurrentFrame();
  const L = LAYOUT.b3;
  const angle = excAngle ?? Math.sin(f * 0.05) * 9;
  return (
    <AbsoluteFill style={{transform: `translate(${tx}px, ${ty}px) scale(${scale})`, transformOrigin: '0 0'}}>
      <PalmOilPlantation scroll={scroll} />
      <InformationLabel box={L.sign} line1="KEBUN" line2="KELAPA SAWIT" sway={Math.sin(f * 0.04) * 1.2} />
      <Excavator box={L.excavator} angle={angle} />
      <Truck box={{...L.truck, x: L.truck.x + truckDx}} />
      <ThroneBack />
      {children}
      <ThroneFront />
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
        <MoneyStack x={40} y={1390} w={250} rows={5} />
        <MoneyStack x={300} y={1400} w={220} rows={3} />
        <Sack x={900} y={1420} s={0.95} />
        <Sack x={1010} y={1440} s={0.8} />
        <Bunch x={60} y={1150} s={0.8} />
        <Bunch x={770} y={1470} s={0.9} />
      </svg>
    </AbsoluteFill>
  );
};
