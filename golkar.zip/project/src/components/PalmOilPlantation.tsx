import type {FC} from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {H, W} from '../data/layout';
import {rand} from '../utils';

const Palm: FC<{x: number; y: number; s: number; sway: number; seed: number}> = ({x, y, s, sway, seed}) => {
  const trunkH = 260;
  const angles = [-172, -150, -128, -106, -84, -62, -40, -18, -2];
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <path
        d={`M-14,0 Q-8,${-trunkH / 2} -9,${-trunkH} L9,${-trunkH} Q8,${-trunkH / 2} 14,0 Z`}
        fill="#7a5230"
        stroke="#2a160c"
        strokeWidth={5}
        strokeLinejoin="round"
      />
      {[0.15, 0.3, 0.45, 0.6, 0.75, 0.9].map((t) => (
        <path key={t} d={`M-11,${-trunkH * t} Q0,${-trunkH * t + 8} 11,${-trunkH * t}`} stroke="#4a2f18" strokeWidth={3} fill="none" />
      ))}
      <g transform={`translate(0 ${-trunkH}) rotate(${sway})`}>
        {angles.map((a, i) => {
          const r = (a * Math.PI) / 180;
          const L = 150 + (i % 2) * 24;
          const ex = Math.cos(r) * L;
          const ey = Math.sin(r) * L + 40 + Math.abs(Math.cos(r)) * 40;
          const cxp = Math.cos(r) * L * 0.5;
          const cyp = Math.sin(r) * L * 0.5 - 38;
          return (
            <g key={i}>
              <path d={`M0,0 Q${cxp},${cyp} ${ex},${ey}`} stroke="#14421a" strokeWidth={16} fill="none" strokeLinecap="round" />
              <path d={`M0,0 Q${cxp},${cyp} ${ex},${ey}`} stroke="#3f9a45" strokeWidth={9} fill="none" strokeLinecap="round" />
            </g>
          );
        })}
        {[-16, 0, 16, -8, 8].map((o, i) => (
          <circle key={i} cx={o} cy={14 + (i % 2) * 14} r={13} fill="#d2501e" stroke="#5a1c08" strokeWidth={3} />
        ))}
      </g>
      <title>{`palm-${seed}`}</title>
    </g>
  );
};

// Perkebunan luas dengan perspektif. `scroll` menggeser barisan pohon (parallax).
export const PalmOilPlantation: FC<{scroll?: number}> = ({scroll = 0}) => {
  const f = useCurrentFrame();
  const vx = 540;
  const horizon = 560;
  const trees: {x: number; y: number; s: number; id: number}[] = [];
  for (let row = 0; row < 7; row++) {
    const d = 0.12 + row * 0.15;
    const spread = 90 + d * d * 620 + d * 380;
    const y = horizon + 30 + d * 780 + (scroll % 20) * d;
    const s = 0.16 + d * 0.95;
    trees.push({x: vx - spread, y, s, id: row * 2});
    trees.push({x: vx + spread, y, s, id: row * 2 + 1});
    trees.push({x: vx - spread * 1.9, y: y - 10 * d, s: s * 0.96, id: row * 2 + 40});
    trees.push({x: vx + spread * 1.9, y: y - 10 * d, s: s * 0.96, id: row * 2 + 41});
  }
  trees.sort((a, b) => a.s - b.s);
  return (
    <AbsoluteFill>
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`}>
        <defs>
          <linearGradient id="po-sky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#ffe9a8" />
            <stop offset="55%" stopColor="#ffc56b" />
            <stop offset="100%" stopColor="#f2994a" />
          </linearGradient>
          <linearGradient id="po-ground" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#4f9f3f" />
            <stop offset="100%" stopColor="#22592a" />
          </linearGradient>
          <radialGradient id="po-sun" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#fffbe0" stopOpacity={1} />
            <stop offset="100%" stopColor="#fff2a8" stopOpacity={0} />
          </radialGradient>
        </defs>
        <rect width={W} height={horizon + 40} fill="url(#po-sky)" />
        <circle cx={820} cy={330} r={260} fill="url(#po-sun)" />
        <circle cx={820} cy={330} r={110} fill="#fff6c9" />
        <g opacity={0.8} fill="#fff4d6">
          <ellipse cx={220 + Math.sin(f * 0.01) * 20} cy={210} rx={150} ry={34} />
          <ellipse cx={310 + Math.sin(f * 0.01) * 20} cy={190} rx={90} ry={30} />
          <ellipse cx={680 - Math.sin(f * 0.012) * 24} cy={140} rx={130} ry={28} />
        </g>
        <path d={`M0,${horizon} Q200,${horizon - 90} 420,${horizon - 30} T860,${horizon - 60} T1080,${horizon - 20} L1080,${horizon + 40} L0,${horizon + 40} Z`} fill="#3a7a3c" />
        <rect y={horizon} width={W} height={H - horizon} fill="url(#po-ground)" />
        <path d={`M${vx - 30},${horizon} L${vx + 30},${horizon} L${vx + 520},${H} L${vx - 520},${H} Z`} fill="#b98b52" opacity={0.9} />
        <path d={`M${vx - 6},${horizon} L${vx + 6},${horizon} L${vx + 60},${H} L${vx - 60},${H} Z`} fill="#d3a96d" opacity={0.7} />
        {trees.map((t) => (
          <Palm key={t.id} x={t.x} y={t.y} s={t.s} sway={Math.sin(f * 0.05 + t.id) * 2.2} seed={t.id + Math.round(rand(t.id) * 3)} />
        ))}
      </svg>
    </AbsoluteFill>
  );
};
