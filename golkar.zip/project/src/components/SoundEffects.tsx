import type {FC} from 'react';
import {Html5Audio, Sequence, interpolate, staticFile} from 'remotion';
import {AUDIO_OFFSET} from '../data/captions';
import {FPS} from '../data/layout';

type Cue = {t: number; file: string; vol: number; dur: number};

// Waktu (detik, PERKIRAAN) mengikuti narasi; geser semuanya lewat AUDIO_OFFSET.
// File di public/sounds/ adalah PLACEHOLDER sintetis; ganti dengan SFX asli bernama sama.
export const CUES: Cue[] = [
  {t: 0.1, file: 'whoosh.mp3', vol: 0.4, dur: 0.6},
  {t: 0.5, file: 'pop.mp3', vol: 0.45, dur: 0.3},
  {t: 2.9, file: 'dramatic_hit.mp3', vol: 0.4, dur: 0.9},
  {t: 4.7, file: 'whoosh.mp3', vol: 0.4, dur: 0.6},
  {t: 6.5, file: 'crown_impact.mp3', vol: 0.5, dur: 0.6},
  {t: 6.55, file: 'sparkle.mp3', vol: 0.35, dur: 0.8},
  {t: 7.5, file: 'crowd_cheer.mp3', vol: 0.25, dur: 2.2},
  {t: 7.6, file: 'heart_pop.mp3', vol: 0.4, dur: 0.3},
  {t: 8.3, file: 'heart_pop.mp3', vol: 0.4, dur: 0.3},
  {t: 11.3, file: 'impact.mp3', vol: 0.45, dur: 0.5},
  {t: 13.2, file: 'burst.mp3', vol: 0.45, dur: 0.6},
  {t: 13.25, file: 'whoosh.mp3', vol: 0.35, dur: 0.6},
  {t: 14.3, file: 'sparkle.mp3', vol: 0.3, dur: 0.8},
  {t: 15.6, file: 'cash_register.mp3', vol: 0.45, dur: 0.8},
  {t: 15.7, file: 'money_fall.mp3', vol: 0.3, dur: 2},
  {t: 20.0, file: 'coin_sparkle.mp3', vol: 0.35, dur: 0.8},
  {t: 21.5, file: 'whoosh.mp3', vol: 0.4, dur: 0.6},
  {t: 25.3, file: 'record_scratch.mp3', vol: 0.5, dur: 0.7},
  {t: 25.8, file: 'paper_flying.mp3', vol: 0.4, dur: 1.1},
  {t: 25.85, file: 'impact.mp3', vol: 0.45, dur: 0.5},
  {t: 26.2, file: 'footsteps.mp3', vol: 0.35, dur: 1},
  {t: 26.9, file: 'whoosh.mp3', vol: 0.25, dur: 0.6},
  {t: 26.95, file: 'suspense.mp3', vol: 0.3, dur: 1.5},
  {t: 29.35, file: 'dream_transition.mp3', vol: 0.45, dur: 0.8},
  {t: 29.4, file: 'record_scratch.mp3', vol: 0.4, dur: 0.7},
  {t: 29.6, file: 'alarm.mp3', vol: 0.3, dur: 2.2},
  {t: 33.0, file: 'thud.mp3', vol: 0.5, dur: 0.6},
  {t: 33.2, file: 'sad_trombone.mp3', vol: 0.4, dur: 1.6},
];

const BGM_BASE = 0.12;

export const SoundEffects: FC = () => (
  <>
    {/* Musik latar: turun hampir senyap saat jeda tantangan di beat 05 (frame 807-882). */}
    <Html5Audio
      src={staticFile('sounds/bgm.mp3')}
      loop
      volume={(f) => interpolate(f, [0, 790, 807, 880, 890, 1050], [BGM_BASE, BGM_BASE, 0.03, 0.03, 0.1, 0.1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})}
    />
    {CUES.map((c, i) => (
      <Sequence key={i} from={Math.round((c.t + AUDIO_OFFSET) * FPS)} durationInFrames={Math.max(1, Math.round(c.dur * FPS))}>
        <Html5Audio src={staticFile(`sounds/${c.file}`)} volume={c.vol} />
      </Sequence>
    ))}
  </>
);
