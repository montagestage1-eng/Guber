import type {FC, ReactNode} from 'react';
import {AbsoluteFill} from 'remotion';
import {H, LAYOUT, W} from '../data/layout';

type Props = {
  top: ReactNode;
  bottom: ReactNode;
  topX?: number; // geser horizontal saat masuk
  bottomX?: number;
  topDim?: number; // 0..1 gelapkan panel atas
  bottomZoom?: number;
  bottomOrigin?: [number, number];
};

// Layar terbagi diagonal atas-bawah (9:16 terlalu sempit untuk kiri-kanan). Garis pemisah putih tebal.
export const SplitScreen: FC<Props> = ({top, bottom, topX = 0, bottomX = 0, topDim = 0, bottomZoom = 1, bottomOrigin = [540, 1200]}) => {
  const a = LAYOUT.b4.topPanelHeight;
  const b = LAYOUT.b4.topPanelHeightRight;
  const clipTop = `polygon(0px 0px, ${W}px 0px, ${W}px ${b}px, 0px ${a}px)`;
  const clipBottom = `polygon(0px ${a}px, ${W}px ${b}px, ${W}px ${H}px, 0px ${H}px)`;
  return (
    <AbsoluteFill>
      <AbsoluteFill style={{clipPath: clipBottom}}>
        <AbsoluteFill
          style={{
            transform: `translateX(${bottomX}px) scale(${bottomZoom})`,
            transformOrigin: `${bottomOrigin[0]}px ${bottomOrigin[1]}px`,
          }}
        >
          {bottom}
        </AbsoluteFill>
      </AbsoluteFill>
      <AbsoluteFill style={{clipPath: clipTop}}>
        <AbsoluteFill style={{transform: `translateX(${topX}px)`}}>{top}</AbsoluteFill>
        {topDim > 0 && <AbsoluteFill style={{background: '#000', opacity: topDim}} />}
      </AbsoluteFill>
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
        <line x1={0} y1={a} x2={W} y2={b} stroke="#111" strokeWidth={30} />
        <line x1={0} y1={a} x2={W} y2={b} stroke="#ffffff" strokeWidth={16} />
      </svg>
    </AbsoluteFill>
  );
};
