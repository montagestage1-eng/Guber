import type {FC} from 'react';
import {spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {CAPTIONS} from '../data/captions';
import {SUBTITLE_BOX} from '../data/layout';

const YELLOW = '#ffd800';

// Subtitle area bawah, maksimal dua baris, kata kunci kuning. Posisi mengikuti SUBTITLE_BOX.
export const Subtitle: FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const cap = CAPTIONS.find((c) => f >= c.startFrame && f < c.endFrame);
  if (!cap) return null;
  const pop = spring({frame: f - cap.startFrame, fps, config: {damping: 12, stiffness: 260}, durationInFrames: 10});
  const size = cap.text.length > 40 ? 50 : 58;
  return (
    <div
      style={{
        position: 'absolute',
        left: SUBTITLE_BOX.x,
        top: SUBTITLE_BOX.y,
        width: SUBTITLE_BOX.w,
        height: SUBTITLE_BOX.h,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        textAlign: 'center',
        transform: `scale(${0.88 + pop * 0.12})`,
      }}
    >
      <div
        style={{
          fontFamily: "'Arial Black', 'Helvetica Neue', Arial, sans-serif",
          fontWeight: 900,
          fontSize: size,
          lineHeight: 1.12,
          color: '#ffffff',
          WebkitTextStroke: '10px #000000',
          paintOrder: 'stroke fill',
          padding: '8px 14px',
          background: 'rgba(0,0,0,0.28)',
          borderRadius: 20,
        }}
      >
        {cap.words.map((w, i) => {
          const active = f >= w.startFrame && f < w.endFrame;
          return (
            <span
              key={i}
              style={{
                color: w.hl ? YELLOW : '#ffffff',
                display: 'inline-block',
                transform: `scale(${active ? 1.08 : 1})`,
                marginRight: i < cap.words.length - 1 ? '0.42em' : 0,
              }}
            >
              {w.text}
            </span>
          );
        })}
      </div>
    </div>
  );
};
