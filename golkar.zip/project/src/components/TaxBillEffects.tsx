import type {FC} from 'react';
import {useCurrentFrame} from 'remotion';
import {H, W} from '../data/layout';
import {ease, lerpV, rand, clamp, type Vec} from '../utils';

type Props = {
  start: number;
  count?: number;
  origin: Vec; // tempat kertas menyembul (di belakang singgasana)
  target: (frame: number) => Vec; // posisi yang dikejar (karakter bos)
};

const Paper: FC<{lf: number; i: number}> = ({lf, i}) => (
  <g>
    <rect x={-70} y={-92} width={140} height={184} rx={8} fill="#fffdf4" stroke="#111" strokeWidth={5} />
    <rect x={-70} y={-92} width={140} height={32} rx={8} fill="#c1121f" stroke="#111" strokeWidth={5} />
    <text x={0} y={-68} textAnchor="middle" fontFamily="'Arial Black', Impact, sans-serif" fontWeight={900} fontSize={22} fill="#fff">
      TAGIHAN
    </text>
    <text x={0} y={-22} textAnchor="middle" fontFamily="'Arial Black', Impact, sans-serif" fontWeight={900} fontSize={40} fill="#c1121f">
      PAJAK
    </text>
    <path d="M-50,10 L50,10 M-50,30 L50,30 M-50,50 L20,50" stroke="#777" strokeWidth={4} strokeLinecap="round" />
    <circle cx={34} cy={62} r={20} fill="none" stroke="#c1121f" strokeWidth={5} />
    <g>
      {/* mata marah: kertas "hidup" */}
      <circle cx={-22} cy={4} r={7} fill="#111" />
      <circle cx={22} cy={4} r={7} fill="#111" />
      <line x1={-34} y1={-10} x2={-12} y2={-3} stroke="#111" strokeWidth={5} strokeLinecap="round" />
      <line x1={34} y1={-10} x2={12} y2={-3} stroke="#111" strokeWidth={5} strokeLinecap="round" />
    </g>
    <path d={`M-18,${84 + Math.sin(lf * 0.6 + i) * 2} Q0,${70 + Math.sin(lf * 0.6 + i) * 4} 18,84`} stroke="#111" strokeWidth={4} fill="none" strokeLinecap="round" />
  </g>
);

// Lembar TAGIHAN PAJAK menyembul dari belakang lalu mengejar target seperti hidup.
export const TaxBillEffects: FC<Props> = ({start, count = 9, origin, target}) => {
  const f = useCurrentFrame();
  const lf = f - start;
  if (lf < 0) return null;
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0, pointerEvents: 'none'}}>
      {Array.from({length: count}).map((_, i) => {
        const delay = i * 2;
        const l = lf - delay;
        if (l < 0) return null;
        const tgt = target(f);
        const off: Vec = [-150 - (i % 3) * 120 + (rand(i + 90) - 0.5) * 60, (rand(i + 50) - 0.5) * 320];
        const dest: Vec = [tgt[0] + off[0], tgt[1] + off[1]];
        const p = ease(clamp(l / 16, 0, 1));
        const pos = lerpV(origin, dest, p);
        const x = pos[0];
        const y = pos[1] - Math.sin(p * Math.PI) * 90 + Math.sin(f * 0.45 + i) * 10;
        const sc = 0.4 + p * 0.65;
        const rot = Math.sin(f * 0.32 + i * 1.3) * 18 + 10;
        return (
          <g key={i} transform={`translate(${x} ${y}) rotate(${rot}) scale(${sc})`}>
            <Paper lf={lf} i={i} />
          </g>
        );
      })}
    </svg>
  );
};
