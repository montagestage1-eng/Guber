import {TOTAL_FRAMES} from './layout';

// Waktu mulai/durasi beat (frame, 30 fps). PERKIRAAN dari SRT; sesuaikan setelah
// narasi.mp3 asli dipasang (lihat README).
export type BeatInfo = {id: number; name: string; start: number; dur: number};

export const BEATS: readonly BeatInfo[] = [
  {id: 1, name: 'Hook', start: 0, dur: 147},
  {id: 2, name: 'Cowok satu-satunya', start: 147, dur: 243},
  {id: 3, name: 'Bos sawit', start: 390, dur: 255},
  {id: 4, name: 'Perbandingan dan punchline', start: 645, dur: 162},
  {id: 5, name: 'Pertanyaan ke penonton', start: 807, dur: 75},
  {id: 6, name: 'Ending mimpi', start: 882, dur: 168},
];

// Beat 01 sengaja diperpanjang agar bertumpuk dengan Beat 02 saat whip pan.
export const WHIP_OVERLAP = 10;

export const BEAT_TOTAL = BEATS.reduce((a, b) => a + b.dur, 0);
if (BEAT_TOTAL !== TOTAL_FRAMES) {
  throw new Error(`Total durasi beat (${BEAT_TOTAL}) harus sama dengan TOTAL_FRAMES (${TOTAL_FRAMES})`);
}
