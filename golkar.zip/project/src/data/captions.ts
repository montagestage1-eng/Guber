import {FPS} from './layout';

// Satu konstanta untuk menggeser semua caption dan efek terhadap narasi (detik).
export const AUDIO_OFFSET = 0;

// SEMUA WAKTU DI BAWAH PERKIRAAN (dari SRT per blok). Belum disinkronkan dengan
// narasi.mp3 asli. Teks mengikuti NASKAH FINAL; SRT hanya dipakai untuk waktu.
export const TIMING_IS_PROVISIONAL = true;

type RawCaption = {text: string; start: number; end: number; hl: string[]};

const RAW: RawCaption[] = [
  {text: 'Eh, gue mau nanya.', start: 0.12, end: 1.6, hl: ['nanya']},
  {text: 'Kalau lo dikasih dua pilihan,', start: 1.6, end: 3.3, hl: ['dua', 'pilihan']},
  {text: 'lo bakal pilih yang mana?', start: 3.3, end: 4.44, hl: ['mana']},
  {text: 'Jadi cowok satu-satunya di dunia.', start: 5.14, end: 7.4, hl: ['satu-satunya']},
  {text: 'Bayangin, semua cewek di dunia cuma punya', start: 7.4, end: 10.44, hl: ['cewek']},
  {text: 'satu cowok buat dipilih, dan itu lo!', start: 10.44, end: 12.98, hl: ['itu', 'lo']},
  {text: 'Atau jadi bos kelapa sawit?', start: 13.62, end: 15.5, hl: ['bos', 'kelapa', 'sawit']},
  {text: 'Duit ngalir terus, punya kebun di mana-mana,', start: 15.5, end: 18.4, hl: ['duit']},
  {text: 'hidup tinggal rebahan sambil nunggu cuan masuk.', start: 18.4, end: 21.5, hl: ['rebahan', 'cuan']},
  {text: 'Coba pikir-pikir dulu.', start: 21.5, end: 22.8, hl: []},
  {text: 'Yang satu dikejar cewek sedunia,', start: 22.8, end: 24.8, hl: ['cewek', 'sedunia']},
  {text: 'yang satu dikejar tagihan pajak.', start: 24.8, end: 26.9, hl: ['tagihan', 'pajak']},
  {text: 'Nah, lo pilih yang mana?', start: 26.9, end: 28.44, hl: ['mana']},
  {text: 'Yaelah, cuma mimpi.', start: 29.4, end: 31.0, hl: ['cuma', 'mimpi']},
  {text: 'Bangun woy, hidup lo masih gini-gini aja!', start: 31.0, end: 33.82, hl: ['gini-gini', 'aja']},
];

export type CaptionWord = {text: string; hl: boolean; startFrame: number; endFrame: number};
export type Caption = {text: string; startFrame: number; endFrame: number; words: CaptionWord[]};

const toFrame = (seconds: number): number => Math.round((seconds + AUDIO_OFFSET) * FPS);
const normalize = (w: string): string => w.toLowerCase().replace(/[.,!?]/g, '');

// Durasi tiap kata dibagi proporsional jumlah karakter (SRT hanya punya waktu per blok).
const build = (c: RawCaption): Caption => {
  const parts = c.text.split(' ');
  const total = parts.reduce((a, p) => a + p.length, 0);
  const span = c.end - c.start;
  let cursor = c.start;
  const words: CaptionWord[] = parts.map((p) => {
    const d = (p.length / total) * span;
    const w: CaptionWord = {
      text: p,
      hl: c.hl.includes(normalize(p)),
      startFrame: toFrame(cursor),
      endFrame: toFrame(cursor + d),
    };
    cursor += d;
    return w;
  });
  return {text: c.text, startFrame: toFrame(c.start), endFrame: toFrame(c.end), words};
};

export const CAPTIONS: Caption[] = RAW.map(build);
