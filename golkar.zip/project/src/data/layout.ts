// Semua koordinat dalam piksel pada kanvas 1080 x 1920 (pojok kiri atas = 0,0).
export const W = 1080;
export const H = 1920;
export const FPS = 30;
// 34,8 dtk dari SRT + sedikit sisa = 1050 frame (35 dtk). Lihat README.
export const TOTAL_FRAMES = 1050;

export type Box = {x: number; y: number; w: number; h: number};

// Zona aman antarmuka TikTok / Reels / Shorts.
export const SAFE = {top: 150, bottom: 1580, right: 900} as const;

export const SUBTITLE_BOX: Box = {x: 90, y: 1360, w: 800, h: 190};

export const LAYOUT = {
  b1: {
    character: {x: 130, y: 560, w: 820, h: 1000},
    questionMark: {x: 440, y: 230, w: 200, h: 240},
    symbolLeft: {x: 90, y: 300, w: 330, h: 330},
    symbolRight: {x: 660, y: 300, w: 330, h: 330},
  },
  b2: {
    character: {x: 300, y: 520, w: 480, h: 860},
    girlFrontL: {x: 20, y: 700, w: 380, h: 600},
    girlFrontR: {x: 680, y: 700, w: 380, h: 600},
    girlBackL: {x: 130, y: 480, w: 300, h: 480},
    girlBackR: {x: 650, y: 480, w: 300, h: 480},
    girlFarL: {x: -60, y: 560, w: 320, h: 500},
    girlFarR: {x: 820, y: 560, w: 320, h: 500},
  },
  b3: {
    sign: {x: 70, y: 230, w: 460, h: 280},
    excavator: {x: 760, y: 440, w: 280, h: 200},
    truck: {x: 640, y: 560, w: 360, h: 220},
    character: {x: 160, y: 760, w: 760, h: 700},
    moneyPile: {x: 40, y: 1180, w: 520, h: 200},
  },
  b4: {
    topPanelHeight: 940, // sisi kiri garis diagonal
    topPanelHeightRight: 860, // sisi kanan garis diagonal
    topCharacter: {x: 250, y: 130, w: 580, h: 700},
    girlL: {x: 20, y: 300, w: 300, h: 480},
    girlR: {x: 760, y: 300, w: 300, h: 480},
    // panel bawah memakai komposisi beat 3 yang digeser turun
    bottomSceneOffsetY: 170,
  },
  b5: {
    character: {x: 120, y: 540, w: 840, h: 900},
    iconLeft: {x: 60, y: 200, w: 300, h: 300},
    iconRight: {x: 720, y: 200, w: 300, h: 300},
    questionMark: {x: 780, y: 600, w: 200, h: 260},
  },
  b6: {
    character: {x: 300, y: 700, w: 520, h: 720},
    clock: {x: 80, y: 1040, w: 240, h: 190},
    exclaim: {x: 760, y: 520, w: 160, h: 220},
  },
} as const;
