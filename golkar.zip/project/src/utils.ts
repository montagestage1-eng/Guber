import {Easing, interpolate, random} from 'remotion';

export type Vec = [number, number];
export type Key = [number, number]; // [frame, nilai]

export const clamp = (v: number, a: number, b: number): number => Math.min(b, Math.max(a, v));
export const lerp = (a: number, b: number, t: number): number => a + (b - a) * t;
export const lerpV = (a: Vec, b: Vec, t: number): Vec => [lerp(a[0], b[0], t), lerp(a[1], b[1], t)];

export const ease = Easing.bezier(0.4, 0, 0.2, 1);

// Keyframe: kf(frame, [frame-frame], [nilai-nilai]). Input harus naik ketat; nilai ditahan di luar rentang.
export const kf = (
  frame: number,
  inputs: number[],
  outputs: number[],
  easing: (n: number) => number = ease,
): number => interpolate(frame, inputs, outputs, {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing});

// Versi pasangan [frame, nilai] (dipakai Camera).
export const kfp = (frame: number, keys: Key[], easing: (n: number) => number = ease): number =>
  kf(
    frame,
    keys.map((k) => k[0]),
    keys.map((k) => k[1]),
    easing,
  );

// Acak ber-seed (0..1), deterministik antar frame.
export const rand = (seed: number): number => random(`seed-${seed}`);

// Dua-tulang IK untuk lengan/kaki stickman.
export const ik = (
  s: Vec,
  t: Vec,
  l1: number,
  l2: number,
  bend: 1 | -1,
): {elbow: Vec; hand: Vec} => {
  const dx = t[0] - s[0];
  const dy = t[1] - s[1];
  const d = Math.hypot(dx, dy) || 0.0001;
  const ux = dx / d;
  const uy = dy / d;
  const dd = clamp(d, Math.abs(l1 - l2) + 0.01, l1 + l2 - 0.01);
  const a = (l1 * l1 - l2 * l2 + dd * dd) / (2 * dd);
  const h = Math.sqrt(Math.max(0, l1 * l1 - a * a));
  return {
    elbow: [s[0] + ux * a - uy * h * bend, s[1] + uy * a + ux * h * bend],
    hand: [s[0] + ux * dd, s[1] + uy * dd],
  };
};

export const pts = (...v: Vec[]): string => v.map((p) => `${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(' ');
