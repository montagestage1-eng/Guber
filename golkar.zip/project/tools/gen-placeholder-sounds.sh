#!/usr/bin/env bash
# Membuat aset audio PLACEHOLDER sintetis dengan ffmpeg (bukan SFX/musik asli).
# Ganti file di public/sounds/ dan public/narasi.mp3 dengan audio asli bernama sama.
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p public/sounds
S=public/sounds
mk() { ffmpeg -y -loglevel error "$@"; }
tone() { # nama freq durasi vol
  local fd
  fd=$(awk -v d="$3" 'BEGIN{printf "%.3f", d-0.02}')
  mk -f lavfi -i "sine=f=$2:d=$3" -af "volume=$4,afade=t=out:st=0.02:d=$fd" "$S/$1.mp3"
}

mk -f lavfi -i "anoisesrc=d=0.6:c=pink:a=0.7" -af "highpass=f=500,lowpass=f=7000,afade=t=in:d=0.25,afade=t=out:st=0.3:d=0.3" $S/whoosh.mp3
tone pop 760 0.12 0.8
mk -f lavfi -i "sine=f=70:d=0.9" -af "volume=1.4,afade=t=out:st=0.05:d=0.85" $S/dramatic_hit.mp3
mk -f lavfi -i "sine=f=95:d=0.6" -af "volume=1.4,afade=t=out:st=0.03:d=0.57" $S/crown_impact.mp3
mk -f lavfi -i "aevalsrc='0.4*sin(2*PI*1800*t)+0.3*sin(2*PI*2400*t)+0.2*sin(2*PI*3200*t)':d=0.8" -af "tremolo=f=14:d=0.8,afade=t=out:st=0.1:d=0.7" $S/sparkle.mp3
mk -f lavfi -i "anoisesrc=d=2.2:c=brown:a=0.6" -af "bandpass=f=900:w=1.2,tremolo=f=7:d=0.5,afade=t=in:d=0.3,afade=t=out:st=1.6:d=0.6" $S/crowd_cheer.mp3
mk -f lavfi -i "aevalsrc='0.7*sin(2*PI*(600+900*t)*t)':d=0.25" -af "afade=t=out:st=0.05:d=0.2" $S/heart_pop.mp3
mk -f lavfi -i "sine=f=140:d=0.5" -af "volume=1.2,afade=t=out:st=0.02:d=0.48" $S/impact.mp3
mk -f lavfi -i "anoisesrc=d=0.6:c=white:a=0.6" -af "lowpass=f=3500,afade=t=in:d=0.05,afade=t=out:st=0.1:d=0.5" $S/burst.mp3
mk -f lavfi -i "aevalsrc='0.6*sin(2*PI*2000*t)*lt(t,0.12)+0.6*sin(2*PI*2600*t)*gte(t,0.2)*lt(t,0.5)':d=0.8" -af "afade=t=out:st=0.3:d=0.5" $S/cash_register.mp3
mk -f lavfi -i "anoisesrc=d=2:c=white:a=0.4" -af "highpass=f=3000,tremolo=f=22:d=0.9,afade=t=out:st=1.2:d=0.8" $S/money_fall.mp3
mk -f lavfi -i "aevalsrc='0.6*sin(2*PI*2800*t)*exp(-6*t)+0.5*sin(2*PI*3600*t)*exp(-5*abs(t-0.15))*gt(t,0.15)':d=0.8" $S/coin_sparkle.mp3
mk -f lavfi -i "aevalsrc='0.8*sin(2*PI*(1600-1500*t)*t)':d=0.5" -af "afade=t=out:st=0.35:d=0.15" $S/record_scratch.mp3
mk -f lavfi -i "anoisesrc=d=1.1:c=pink:a=0.5" -af "highpass=f=1500,tremolo=f=16:d=0.7,afade=t=out:st=0.6:d=0.5" $S/paper_flying.mp3
mk -f lavfi -i "aevalsrc='0.9*sin(2*PI*90*t)*lt(mod(t,0.22),0.05)':d=1" -af "afade=t=out:st=0.7:d=0.3" $S/footsteps.mp3
mk -f lavfi -i "aevalsrc='0.5*sin(2*PI*(120+40*t)*t)':d=1.5" -af "tremolo=f=5:d=0.8,afade=t=in:d=0.4,afade=t=out:st=1:d=0.5" $S/suspense.mp3
mk -f lavfi -i "aevalsrc='0.5*sin(2*PI*(500+1200*t)*t)':d=0.8" -af "tremolo=f=9:d=0.6,afade=t=out:st=0.4:d=0.4" $S/dream_transition.mp3
mk -f lavfi -i "aevalsrc='0.6*gt(sin(2*PI*1500*t),0)*lt(mod(t,0.25),0.1)':d=2.2" -af "lowpass=f=4000,afade=t=out:st=1.9:d=0.3" $S/alarm.mp3
mk -f lavfi -i "sine=f=55:d=0.6" -af "volume=1.6,afade=t=out:st=0.03:d=0.57" $S/thud.mp3
mk -f lavfi -i "aevalsrc='0.6*sin(2*PI*(330-80*t)*t)*lt(t,0.5)+0.6*sin(2*PI*(280-90*(t-0.5))*t)*gte(t,0.5)*lt(t,1.0)+0.6*sin(2*PI*(230-90*(t-1))*t)*gte(t,1.0)':d=1.6" -af "tremolo=f=6:d=0.2,afade=t=out:st=1.2:d=0.4" $S/sad_trombone.mp3
# Musik latar placeholder: arpeggio sederhana 36 dtk
mk -f lavfi -i "aevalsrc='0.25*sin(2*PI*261.6*t)*lt(mod(t,0.5),0.12)+0.25*sin(2*PI*329.6*t)*(gte(mod(t,0.5),0.25))*(lt(mod(t,0.5),0.37))':d=36" -af "lowpass=f=1800,afade=t=in:d=1,afade=t=out:st=34:d=2" $S/bgm.mp3
# Narasi placeholder: HENING 35 dtk (GANTI dengan narasi.mp3 asli)
mk -f lavfi -i "anullsrc=r=44100:cl=mono" -t 35 public/narasi.mp3
echo "Selesai: $(ls $S | wc -l) file di $S + public/narasi.mp3"
